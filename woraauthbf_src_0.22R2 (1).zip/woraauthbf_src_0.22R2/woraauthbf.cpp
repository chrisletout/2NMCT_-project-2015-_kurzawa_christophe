//The code is released under GPLv2 (http://www.gnu.org/licenses/gpl-2.0.html), by Laszlo Toth.
//Use the code at your own responsibility.
//For help and disclaimer please visit:
//  http://www.soonerorlater.hu/index.khtml?article_id=513

//This should not be here, but it is easier to port to other platforms
#define _CRT_SECURE_NO_DEPRECATE

#include "stdafx.h"
#include "woraauthbf.h"
#include "getopt.h"

//This is not so nice, but works...
authinfo8i authinfo8i_array[10000];
hashinfo hashinfo_array[10000];
authinfo10g authinfo10g_array[10000];
authinfo9i authinfo9i_array[10000];
hashinfo11g hashinfo11g_array[10000];
//array for permutation
char* topermute[10000];
int topermute_pos=0;

static struct option long_options[] ={
		{"pwd", required_argument, 0, 'p'},
		{"dict", required_argument, 0, 'd'},
		{"type", required_argument, 0, 't'},
		{"max", required_argument, 0, 'm'},
		{"charset", required_argument, 0, 'c'},
		{"sess", required_argument, 0, 's'},
		{"dll", required_argument, 0, 'o'},
		{"perm", required_argument, 0, 'e'},
		{"noarr", no_argument, 0, 'n'},
		{"from", required_argument, 0, 'b'},
		{"prev", no_argument, 0, 'f'},
		{0,0,0,0}
};


int main(int argc, char* argv[])
{
	char message[1000];
	int NumberOfProc,i;
	long long NumberOfPwd;
	int PwdFileSize;

	SYSTEM_INFO siSysInfo;
	//password file name
	char* pwdfn=NULL;
	//dictionary file name
	char* dictfn=NULL;
	//hash type
	char* which=NULL;
	//session file
	char* sessfn=NULL;
	int found=0;
	long long checked=0;
	//Max size of the passwords during the bruteforce attack. The limit is 10 character
	int length=6;
	char* charset=NULL;
	//Number of characters in a charset
	int charset_length;
	//for loading session files
	long long start=0;
	long long end=0;
	//Oracle dll (oran10.dll)
	char* dll=NULL;
	//permutations parameter
	int perm=1;
	pcrecpp::RE reperm("[1230]{1}");
	//start the array thread? This necessary for testing purposes
	int startarr=1;
	//Load the previous run result list. It loads based on the password file name.
	int prevres=0;
	//Oracle functions for 9i and 10g authentication
	PZTVO5KD pztvo5kd=NULL;
	PZTVO5PD pztvo5pd=NULL;
	PZTVO5CSK pztvo5csk=NULL;
	PZTVOPD pztvopd=NULL;
	//Logfile handle stores the found passwords.
	FILE* logfh;
	//Starting form this password
	char* frompwd=NULL;
	long long fromnum=0;
	BIGNUM* bn_fromnum;

	pthread_t      *pthreads;
	pthread_t		status_thread;
	pthread_t		array_thread;
	pthread_attr_t  pthread_custom_attr;
	threadparm8i_t	*pthreadparm8i;

	//parameter handling 
	int option_index = 0;
	int opt = 0;
	

	time_t time_start,time_end;

	time(&time_start);
	
	//This can solve a lots of problem. For example in the case of 8i auth
	//the result comparison taks in the account the zeroes, until to the AUTH_PASSWORD
	//length.
	memset(authinfo8i_array,0,sizeof(authinfo8i_array));
	memset(hashinfo_array,0,sizeof(hashinfo));
	memset(authinfo10g_array,0,sizeof(authinfo10g));
	memset(authinfo9i_array,0,sizeof(authinfo9i));
	memset(hashinfo11g_array,0,sizeof(hashinfo11g));


	//process arguments
	opt = getopt_long (argc, argv, "p:d:t:m:c:s:o:e:b:fn",
		long_options, &option_index);
   
   while(opt != -1){
	   switch(opt){
		   case 'p':
				pwdfn=optarg;
				break;
			case 'd':
				dictfn=optarg;
				break;
			case 't':
				which=optarg;
				break;
			case 'm':
				length=atoi(optarg);
				if(length>10){
					sprintf(message,"The maximum password length in bruteforce mode is 10!\n");
					write_error(message);
					return -1;
				}
				if(length==0){
					length=6;
				}
				break;
			case 'c':
				charset=optarg;
				break;
			case 's':
				sessfn=optarg;
				break;
			case 'o':
				dll=optarg;
				break;
			case 'e':
				if(reperm.FullMatch(optarg)){
					perm=atoi(optarg);
				}else{
					sprintf(message,"The perm value can be 0, 1, 2 or 3!\n");
					write_error(message);
					return -1;
				}
				break;
			case 'n':
				startarr=0;
				break;
			case 'b':
				frompwd=optarg;
				break;
			case 'f':
				prevres=1;
				break;
	   }
	   opt = getopt_long (argc, argv, "p:d:t:m:c:s:o:e:b:fn", long_options, &option_index);
	}
	
	if(perm >= 1){
		//perm = 1;
		sprintf(message,"Usernames will be permuted!\n");
		write_error(message);
	}else{
		perm=0;
	}

	if(sessfn){
		pwdfn=(char*)malloc(_MAX_PATH);
		dictfn=(char*)malloc(_MAX_PATH);
		which=(char*)malloc(8);
		charset=(char*)malloc(9);
		NumberOfProc=load_session_file(sessfn, &pthreadparm8i, pwdfn, dictfn, which, charset, &length, &found);
		//The found variable should not set here after the arraythread impmenetation
		found=0;
		if(NumberOfProc==-1){
			sprintf(message,"Could not load session file: %s!\n", sessfn);
			write_error(message);
			return -1;
		}
		if(strncmp(dictfn,"none",4)==0){
			dictfn=NULL;
		}
		sprintf(message,"The number of processors from the session file: %d\n",NumberOfProc);
		write_error(message);
	}else{
		//get the number of processors
		GetSystemInfo(&siSysInfo);
		NumberOfProc= siSysInfo.dwNumberOfProcessors;
		sprintf(message,"The number of processors: %d\n",NumberOfProc);
		//NumberOfProc=1;
		write_error(message);
		//Parrameter array for the threads, if there is no session file the initialization
		//happens here. The +1 for NumberOfProc is for the array thread.
		pthreadparm8i = (threadparm8i_t *) malloc((NumberOfProc +1 )* sizeof(*pthreadparm8i));
	}

	//Initialize the variables for thread handling
	pthreads = (pthread_t *) malloc(NumberOfProc * sizeof(pthread_t));
	pthread_attr_init(&pthread_custom_attr);

	if((pwdfn==NULL)){
		sprintf(message, "Usage: %s -p pwdfile [-d dictfile] -t type -m maxpwdlength -c charset\n", argv[0]);
		write_error(message);
		return -1;
	}

	if(which==NULL){
		which="hash";
	}

	//if(!((strncmp(which,"8i",2)==0)||(strncmp(which,"hash",4)==0) || (strncmp(which,"10g",3)==0) || (strncmp(which,"9i",2)==0) || (strncmp(which,"11g",3)==0) || (strncmp(which,"11g10g",6)==0))){
	if(!((strncmp(which,"8i",2)==0)||(strncmp(which,"hash",4)==0) || (strncmp(which,"10g",3)==0) || (strncmp(which,"9i",2)==0) || (strncmp(which,"11g10g",6)==0))){
		sprintf(message, "Usage: Usage: %s -p pwdfile [-d dictfile] -t type -m maxpwdlength -c charset\n", argv[0]);
		write_error(message);
		return -1;
	}

	if(charset==NULL || !((strncmp(charset,"alpha",5)==0) || (strncmp(charset,"alphanum",8)==0) || (strncmp(charset,"all",3)==0))){
		charset=(char*)malloc(9);
		strncpy(charset,"alpha",8);
	}

	
	
	//Loading oracle DLL and functions
	if((strncmp(which,"10g",3)==0) || (strncmp(which,"9i",2)==0)){
		if(dll){
			//Loading the oracle DLL %ORACLE_HOME%\bin\oran10.dll
			HMODULE hMod = LoadLibraryA (dll);
			if (NULL == hMod)
			{
				sprintf (message,"LoadLibrary failed: %s\n",dll);
				write_error(message);
				return -1;
			}

			//Load functions
			pztvo5kd = (PZTVO5KD) GetProcAddress (hMod, "ztvo5kd");
			if (NULL == pztvo5kd)
			{
				sprintf(message,"GetProcAddress ztvo5kd failed!\n");
				write_error(message);
				return -1;
			}

			pztvo5pd = (PZTVO5PD) GetProcAddress (hMod, "ztvo5pd");
			if (NULL == pztvo5pd)
			{
				sprintf (message,"GetProcAddress ztvo5pd failed!\n");
				write_error(message);
				return -1;
			}

			pztvo5csk = (PZTVO5CSK) GetProcAddress (hMod, "ztvo5csk");
			if (NULL == pztvo5csk)
			{
				sprintf (message,"GetProcAddress ztvo5csk failed!\n");
				write_error(message);
				return -1;
			}
			
			pztvopd = (PZTVOPD) GetProcAddress (hMod, "ztvopd");
			if (NULL == pztvopd)
			{
				sprintf (message,"GetProcAddress ztvopd failed!\n");
				write_error(message);
				return -1;
			}
		}else{
			sprintf (message,"9i and 10g authentication need the oran10.dll\n");
			write_error(message);
			return -1;
		}
	}
	if((dictfn!=NULL)){

			//Get the number of the password in the dictionary file
			NumberOfPwd=get_dict_size(dictfn);
			if(NumberOfPwd==-1){
				sprintf (message,"Could not open dict file!\n");
				write_error(message);
				return -1;
			}
	}else{
		if(!strncmp(charset,"alpha",5)){charset_length = 26;}
		if(!strncmp(charset,"alphanum",8)) {charset_length = 36;}
		if(!strncmp(charset,"all",3)) {charset_length = 68;}
		if(frompwd!=NULL){
			bn_fromnum=BN_new();
			get_number(frompwd, charset_length, bn_fromnum);
			fromnum=_atoi64(BN_bn2dec(bn_fromnum));
		}

		NumberOfPwd=0;
		for(int i=0; i < length; i++){
			NumberOfPwd += pow((long double)charset_length,length-i);
		}
	}
	
	sprintf(message,"Number of pwds to check: %lld\nNumber of pwds to check by thread: %lld\n",
		NumberOfPwd, NumberOfPwd / NumberOfProc);
	write_error(message);
	

	//load passsword file into the memory and collect usernames to the array based function
	if(!strncmp(which,"8i",2)){
		PwdFileSize=load_8ipwd_file(pwdfn, authinfo8i_array);
		for(i=0; i<PwdFileSize; i++){
			topermute[i+topermute_pos]=authinfo8i_array[i].username;
		}
		topermute_pos+=i;
	}
	if(!strncmp(which,"9i",2)){
		PwdFileSize=load_9ipwd_file(pwdfn, authinfo9i_array);
		for(i=0; i<PwdFileSize; i++){
			topermute[i+topermute_pos]=authinfo9i_array[i].username;
		}
		topermute_pos+=i;
	}
	if(!strncmp(which,"10g",3)){
		PwdFileSize=load_10gpwd_file(pwdfn, authinfo10g_array);
		for(i=0; i<PwdFileSize; i++){
			topermute[i+topermute_pos]=authinfo10g_array[i].username;
		}
		topermute_pos+=i;
	}
	if(!strncmp(which,"hash",4)){
		PwdFileSize=load_hashpwd_file(pwdfn, hashinfo11g_array);
		for(i=0; i<PwdFileSize; i++){
			topermute[i+topermute_pos]=hashinfo11g_array[i].username;
		}
		topermute_pos+=i;
	}
	
	if((!strncmp(which,"11g10g",6)) || (!strncmp(which,"11g",3))){
		PwdFileSize=load_11ghashpwd_file(pwdfn, hashinfo11g_array);
		for(i=0; i<PwdFileSize; i++){
			topermute[i+topermute_pos]=hashinfo11g_array[i].username;
		}
		topermute_pos+=i;
	}
	
	if(PwdFileSize==-1){
		sprintf(message, "Could not open pwd file!\n");
		write_error(message);
		return -1;
	}

	
	//For speed comparsion with single threaded application.
	//NumberOfProc=3;
	if(dictfn==NULL){
		sprintf(message,"Password file: %s, charset: %s, maximum length: %d, type: %s\n", pwdfn, charset, length, which);
		write_error(message);
	}else{
		sprintf(message,"Password file: %s, dictionary file: %s, type: %s\n", pwdfn, dictfn, which);
		write_error(message);
	}

	logfh=open_log_file(pwdfn);
	if(logfh==NULL){
		return -1;
	}

	for(i=0;i<=NumberOfProc;i++){
		if(!sessfn){
			pthreadparm8i[i].start=i*(NumberOfPwd/NumberOfProc)+1;
			if(i == NumberOfProc-1){
				pthreadparm8i[i].end=NumberOfPwd;
			}else{
				pthreadparm8i[i].end=(i+1)*(NumberOfPwd/NumberOfProc);
			}
			if(i == 0){
				pthreadparm8i[i].start+=fromnum;
			}
			pthreadparm8i[i].checked_by_thread=0;
		}
			pthreadparm8i[i].dictfn = dictfn;
			pthreadparm8i[i].found = &found;
			pthreadparm8i[i].checked = &checked;
			pthreadparm8i[i].charset = charset;
			pthreadparm8i[i].length = length;
			pthreadparm8i[i].NumberOfProc = NumberOfProc;
			pthreadparm8i[i].pwdfn = pwdfn;
			pthreadparm8i[i].which = which;
			pthreadparm8i[i].pztvo5csk=pztvo5csk;
			pthreadparm8i[i].pztvo5kd=pztvo5kd;
			pthreadparm8i[i].pztvo5pd=pztvo5pd;
			pthreadparm8i[i].pztvopd=pztvopd;
			pthreadparm8i[i].logfh=logfh;
			pthreadparm8i[i].pwarray=topermute;
			pthreadparm8i[i].pwarray_size=topermute_pos;
			pthreadparm8i[i].perm=perm;

		if(!strncmp(which,"8i",2)){
				pthreadparm8i[i].case_which = '8';
				pthreadparm8i[i].ad_array = authinfo8i_array;
		}
		if(!strncmp(which,"9i",2)){
				pthreadparm8i[i].case_which = '9';
				pthreadparm8i[i].ad_array = authinfo9i_array;
		}
		if(!strncmp(which,"hash",4)){
				pthreadparm8i[i].case_which = 'h';
				pthreadparm8i[i].ad_array = hashinfo11g_array;
		}
		if(!strncmp(which,"10g",3)){
				pthreadparm8i[i].case_which = 'g';
				pthreadparm8i[i].ad_array = authinfo10g_array;
		}
		if((!strncmp(which,"11g10g",6)) || (!strncmp(which,"11g",3))){
				pthreadparm8i[i].case_which = 'f';
				pthreadparm8i[i].ad_array = hashinfo11g_array;
		}
		pthreadparm8i[i].aa_size = PwdFileSize;
		
		//It would be cleaner design if this happenns before the for cycle, but case_which is already filled.
		if((prevres || sessfn) && i==0){
			int which_res=0;
			if(sessfn){
				if(!strncmp("oraauth.sess.0",sessfn,20)){
					which_res=0;
				}else{
					which_res=1;
				}
			}
			*(pthreadparm8i[i].found)=load_foundpwdlist(pthreadparm8i[i].case_which, 
				pthreadparm8i[i].ad_array, pwdfn, which_res);
		}
		if(*(pthreadparm8i[i].found)==-1){
			*(pthreadparm8i[i].found)=0;
		}

		//dirty trick to go forward to the array threads and use the values from here
		if(i!=NumberOfProc){
			if(!strncmp(which,"8i",2)){
				if(dictfn!=NULL){
					pthread_create(&pthreads[i], &pthread_custom_attr, auththread8i, pthreadparm8i+i);
				}else{
					pthread_create(&pthreads[i], &pthread_custom_attr, bfthread8i, pthreadparm8i+i);
				}
			}
			if(!strncmp(which,"9i",2)){
				if(dictfn!=NULL){
					pthread_create(&pthreads[i], &pthread_custom_attr, auththread9i, pthreadparm8i+i);
				}else{
					pthread_create(&pthreads[i], &pthread_custom_attr, bfthread9i, pthreadparm8i+i);
				}
			}
			if(!strncmp(which,"hash",4)){
				if(dictfn!=NULL){
					pthread_create(&pthreads[i], &pthread_custom_attr, hashthread, pthreadparm8i+i);
				}else{
					pthread_create(&pthreads[i], &pthread_custom_attr, hashthread_bf_pre, pthreadparm8i+i);
				}
			}
			if(!strncmp(which,"10g",3)){
				if(dictfn!=NULL){
					pthread_create(&pthreads[i], &pthread_custom_attr, auththread10g, pthreadparm8i+i);
				}else{
					pthread_create(&pthreads[i], &pthread_custom_attr, bfthread10g, pthreadparm8i+i);
				}
			}
			if(!strncmp(which,"11g10g",6)){
				if(dictfn!=NULL){
					pthread_create(&pthreads[i], &pthread_custom_attr, hashthread, pthreadparm8i+i);
				}else{
					pthread_create(&pthreads[i], &pthread_custom_attr, hashthread_bf_pre, pthreadparm8i+i);
				}
			}
			/*if(!strncmp(which,"11g",3)){
				if(dictfn!=NULL){
					//pthread_create(&pthreads[i], &pthread_custom_attr, auththread10g, pthreadparm8i+i);
				}else{
					pthread_create(&pthreads[i], &pthread_custom_attr, bfhashthread11g10g, pthreadparm8i+i);
				}
			}*/
		}

	}

	pthread_create(&status_thread, &pthread_custom_attr, check_status, pthreadparm8i);

	
	//Load the default password list file to the end of the to permute array.
	//The default passwords will not be permuted.
	int DefaultSize=load_default_file(topermute, PwdFileSize);
	if(DefaultSize==-1){
		sprintf(message,"Could not open default.txt file! Deafult passwords will not be checked!\n");
		write_error(message);
		DefaultSize=0;
	}
	
	pthreadparm8i[i-1].pwarray_size+=DefaultSize;

	if(startarr){
		pthread_create(&array_thread, &pthread_custom_attr, arraythread, pthreadparm8i+(i-1));
		pthread_join(array_thread, NULL);
	}
	
	for (int j = 0; j < NumberOfProc; j++)
	{
		pthread_join(pthreads[j], NULL);
	}

	time(&time_end);
	
	pthread_cancel(status_thread);

	time_t ElapsedTime=time_end-time_start;
	sprintf(message,"Elpased time: %ds\n", ElapsedTime);
	write_error(message);
	sprintf(message,"Checked passwords: %lld\n", checked);
	write_error(message);

	save_foundpwdlist(pthreadparm8i->case_which, pthreadparm8i->ad_array, pthreadparm8i->aa_size, pwdfn, 0);

	if(ElapsedTime){
		sprintf(message,"Password / Second: %d\n", (checked)/(time_end-time_start));
		write_error(message);
	}
	fclose(logfh);

	return 0;
}

