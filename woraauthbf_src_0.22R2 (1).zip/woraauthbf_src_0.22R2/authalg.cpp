//The code is released under GPLv2 (http://www.gnu.org/licenses/gpl-2.0.html), by Laszlo Toth.
//Use the code at your own responsibility.
//For help and disclaimer please visit:
//  http://www.soonerorlater.hu/index.khtml?article_id=513

#define _CRT_SECURE_NO_DEPRECATE

#include "stdafx.h"
#include "woraauthbf.h"
#include <math.h>
#include <list>
using namespace std;

pthread_mutex_t authinfo_mutex = PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t checked_mutex = PTHREAD_MUTEX_INITIALIZER;

inline int create_usernamepwd(char* username, const char* pwd, unsigned char* usernamepwd){

	unsigned int k;

	int l = 0;
	for(k = 0; username[k]!= 0; k++){
		usernamepwd[l]=0;
		//The username should be capitalized already
		//This should be done when the password file is opened
		usernamepwd[l+1]=username[k];
		l+=2;
	}

	for(k = 0; pwd[k]!=0; k++){
		usernamepwd[l]=0;
		//usernamepwd[l+1]=toupper(pwd[k]);
		usernamepwd[l+1]=pwd[k];
		l+=2;
	} 

	return l;

}

inline int create_usernamepwd2(char* username, const unsigned char* pwd, int pwdlen, unsigned char* usernamepwd){

	unsigned int k;

	int l = 0;
	for(k = 0; username[k]!= 0; k++){
		usernamepwd[l]=0;
		//The username should be capitalized already
		//This should be done when the password file is opened
		usernamepwd[l+1]=username[k];
		l+=2;
	}

	for(k = 0; k < pwdlen; k++){
		//usernamepwd[l]=0;
		//usernamepwd[l+1]=toupper(pwd[k]);
		usernamepwd[l+k]=pwd[k];
		//l+=2;
	} 

	return l+k;

}

void* auththread8i(void* arg){
	unsigned char key1st[8]={0x01,0x23,0x45,0x67,0x89,0xAB,0xCD,0xEF};
	DES_key_schedule dks;

	char tmp[257];
	FILE* dictf;
	long i=0;
	long long m=0;
	int k=0;
	long checked=0;

	unsigned char key2nd[8];
	unsigned char auth_sesskey[8];
	unsigned char pwdhash[16];
	unsigned char pwd[255];
	unsigned char usernamepwd[1200];




	threadparm8i_t *p = (threadparm8i_t*) arg;
	authinfo8i* ad_array=(authinfo8i*)p->ad_array;


	DES_set_odd_parity((DES_cblock*)key1st);
	DES_set_key_checked((DES_cblock*)key1st, &dks);


	dictf = fopen(p->dictfn, "r");
	if (dictf == NULL ){

		return 0;
	}

	//seek forward in the dict file
	for(i=1;i<(p->start+p->checked_by_thread);i++){
		fgets(tmp,255,dictf);
	}

	printf("Start: %lld End: %lld\n", p->start+p->checked_by_thread, p->end);

	for(m=p->start+p->checked_by_thread;m<=p->end;m++){
		memset(tmp,0,255);
		fgets( tmp, 255,dictf);
		size_t pl=strlen(tmp);
		tmp[pl-1]='\0';
		for(int q=0;q<pl;q++){tmp[q]=toupper(tmp[q]);}
		//This will be in the session file
		p->checked_by_thread++;
		for(i = 0;i < p->aa_size;i++){
			if(ad_array[i].found){continue;}
			memset(pwd,0,255);
			checked++;
			//This is used when the check_status writes out the current status and speed on to the screen
			p->checked_by_thread_summ=checked;

			//produce usernamepwd
			int l = create_usernamepwd(ad_array[i].username, tmp, usernamepwd);

			create_key(usernamepwd, key2nd, l, dks);
			create_hash(usernamepwd, pwdhash, l, key2nd);
			decrypt_rnd(ad_array[i].capauth_sesskey, auth_sesskey, 8, pwdhash);
			decrypt_pwd(ad_array[i].auth_password, pwd, ad_array[i].auth_pwd_len, auth_sesskey);

			//Compare the password and the decrypted value
			for(k=0; k<ad_array[i].auth_pwd_len; k++){
				if(toupper(pwd[k])!=toupper(tmp[k])){
					break;
				}
			}

			//If found print to the screen and save into a file
			if(k==ad_array[i].auth_pwd_len){
				pthread_mutex_lock(&authinfo_mutex);
				if(!ad_array[i].found){
					printf("Password found: %s:%s:%s:%s:%s:%s\n",ad_array[i].username, tmp,
						ad_array[i].src_ip,ad_array[i].src_port,ad_array[i].dst_ip,
						ad_array[i].dst_port);
					fprintf(p->logfh,"Password found: %s:%s:%s:%s:%s:%s\n",ad_array[i].username, tmp,
						ad_array[i].src_ip,ad_array[i].src_port,ad_array[i].dst_ip,
						ad_array[i].dst_port);
					ad_array[i].found=1;
					(*(p->found))++;
				}
				pthread_mutex_unlock(&authinfo_mutex);
			}
		}

		//Check whether all pwd in password file is found or not. If found, finish the thread
		if(*(p->found)==p->aa_size){
			pthread_mutex_lock(&checked_mutex);
			*(p->checked)+=checked;
			pthread_mutex_unlock(&checked_mutex);
			fclose(dictf);
			return 0;
		}
	}
	pthread_mutex_lock(&checked_mutex);
	*(p->checked)+=checked;
	pthread_mutex_unlock(&checked_mutex);

	fclose(dictf);
	return 0;
}

void* bfthread8i(void* arg){

	unsigned char key1st[8]={0x01,0x23,0x45,0x67,0x89,0xAB,0xCD,0xEF};
	DES_key_schedule dks;

	int password_token[12];
	int charset_length;
	long long NumberOfPwds;
	//start bruteforce from
	long long start;
	//stop bruteforce here
	long long stop;
	//max password length
	int length;
	long long counter;

	char all[69]="ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*()-_+=~`[]{}|\\:;\"'<>,.?/";
	char alpha[27]="ABCDEFGHIJKLMNOPQRSTUVWXYZ";
	char alphanum[37]="ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
	char* act_charset=NULL;


	char tmp[257];
	long long i=0;
	long long m=0;
	int k=0;
	long long checked=0;

	unsigned char key2nd[8];
	unsigned char auth_sesskey[8];
	unsigned char pwdhash[16];
	unsigned char usernamepwd[1200];
	unsigned char pwd[255];
	//the size of the to be checked password
	size_t pl;


	threadparm8i_t *p = (threadparm8i_t*) arg;
	authinfo8i* ad_array=(authinfo8i*)p->ad_array;
	length=p->length;
	start=p->start+p->checked_by_thread-1;
	stop=p->end;

	printf("Start: %lld End: %lld\n", start, stop);

	DES_set_odd_parity((DES_cblock*)key1st);
	DES_set_key_checked((DES_cblock*)key1st, &dks);



	if(!strncmp(p->charset,"alpha",5)){charset_length = 26;act_charset=alpha;}
	if(!strncmp(p->charset,"alphanum",8)) {charset_length = 36;act_charset=alphanum;}
	if(!strncmp(p->charset,"all",3)) {charset_length = 68;act_charset=all;}
	if(!act_charset){charset_length = 68;act_charset=all;}

	NumberOfPwds=stop-start;

	
	for(int i=0; i<length; i++)
	{
		password_token[i] = -1;
	}

	/*setup the first password, calculate in the number system of charset length
	int j=0;
	for(int i=length-1;i>=0;i--){
		j=length-i-1;
		long double t=pow((long double)charset_length,i);
		long long q=start/t;
		if(q!=0){password_token[j]=q-1;}else{password_token[j]=-1;}
		if(q!=0){
			start=start-t*q;
		}	
	}*/
	get_firstpwd(start,password_token,charset_length, length);

	counter=0;
	bool endofall = false;
	int pwd_file_size=p->aa_size;

	while((!endofall) && (counter!=NumberOfPwds))
	{
		counter++;
		//This will be in the session file
		p->checked_by_thread++;

		for(int i=length-1;i>=0;i--)
		{
			password_token[i]++;
			if(password_token[i]<charset_length){
				break;
			}else if(password_token[0]==charset_length){
				endofall=true;
			}
			else 
			{
				password_token[i] = 0;
			}
		}

		//Generate the password that will be checked from the password_token
		pl=0;
		//12 is enough, because the maximum password length is 10 in bruteforce mode
		memset(tmp,0,12);
		for ( int j=0; j<length; j++){
			if(password_token[j]!=-1){
				tmp[pl]=act_charset[password_token[j]];
				pl++;
			}
		}

		for(int i = 0;i < pwd_file_size;i++){
			if(ad_array[i].found){continue;}
			//12 is enough, because the maximum password length is 10 in bruteforce mode
			memset(pwd,0,12);
			checked++;
			//This is used when the check_status writes out the current status and speed on to the screen
			p->checked_by_thread_summ=checked;
			//produce usernamepwd
			int l = create_usernamepwd(ad_array[i].username, tmp, usernamepwd);

			//Start 8i authentication algorithm
			create_key(usernamepwd, key2nd, l, dks);
			create_hash(usernamepwd, pwdhash, l, key2nd);
			decrypt_rnd(ad_array[i].capauth_sesskey, auth_sesskey, 8, pwdhash);
			decrypt_pwd(ad_array[i].auth_password, pwd, ad_array[i].auth_pwd_len, auth_sesskey);
			//End 8i authentication algorithm

			//Compare the password and the decrypted value
			for(k=0; k<12; k++){
				if(toupper(pwd[k])!=toupper(tmp[k])){
					break;
				}
			}

			//If found print to the screen and save into a file
			if(k==12){
				pthread_mutex_lock(&authinfo_mutex);
				if(!ad_array[i].found){
					printf("Password found: %s:%s:%s:%s:%s:%s\n",ad_array[i].username, tmp,
						ad_array[i].src_ip,ad_array[i].src_port,ad_array[i].dst_ip,
						ad_array[i].dst_port);
					fprintf(p->logfh,"Password found: %s:%s:%s:%s:%s:%s\n",ad_array[i].username, tmp,
						ad_array[i].src_ip,ad_array[i].src_port,ad_array[i].dst_ip,
						ad_array[i].dst_port);
					ad_array[i].found=1;
					(*(p->found))++;
				}
				pthread_mutex_unlock(&authinfo_mutex);
			}

		}

		//Check whether all pwd in password file is found or not. If found, finish the thread
		if(*(p->found)==p->aa_size){
			pthread_mutex_lock(&checked_mutex);
			*(p->checked)+=checked;
			pthread_mutex_unlock(&checked_mutex);
			return 0;
		}
	}
	pthread_mutex_lock(&checked_mutex);
	*(p->checked)+=checked;
	pthread_mutex_unlock(&checked_mutex);

	return 0;
}




//This is the template function for dictionary attack
void* hashthread(void* arg){

	unsigned char key1st[8]={0x01,0x23,0x45,0x67,0x89,0xAB,0xCD,0xEF};
	DES_key_schedule dks;

	char tmp[257];
	//for 11g checking. It will contain the lower uppercase version of the password
	char tmp11g[257];
	FILE* dictf;
	long i=0;
	long long m=0;
	int k=0;
	long checked=0;

	unsigned char key2nd[8];
	unsigned char pwdhash[16];
	unsigned char usernamepwd[1200];



	threadparm8i_t *p = (threadparm8i_t*) arg;
	hashinfo11g* ad_array=(hashinfo11g*)p->ad_array;


	DES_set_odd_parity((DES_cblock*)key1st);
	DES_set_key_checked((DES_cblock*)key1st, &dks);

	dictf = fopen(p->dictfn, "r");
	if (dictf == NULL ){

		return 0;
	}

	//seek forward in the dict file
	for(i=1;i<(p->start+p->checked_by_thread);i++){
		fgets(tmp,255,dictf);
	}

	printf("Start: %lld End: %lld\n", p->start+p->checked_by_thread, p->end);

	for(m=p->start+p->checked_by_thread;m<=p->end;m++){
		fgets(tmp, 255,dictf);
		size_t pl=strlen(tmp);
		tmp[pl-1]='\0';
		
		for(int q=0;q<pl;q++){tmp[q]=toupper(tmp[q]);}
		//This will be in the session file
		p->checked_by_thread++;
		for(i = 0;i < p->aa_size;i++){
			if(ad_array[i].found){continue;}
			checked++;
			//This is used when the check_status writes out the current status and speed on to the screen
			p->checked_by_thread_summ=checked;
			//produce usernamepwd
			int l = create_usernamepwd(ad_array[i].username, tmp, usernamepwd);

			create_key(usernamepwd, key2nd, l, dks);
			create_hash(usernamepwd, pwdhash, l, key2nd);

			//Compare the hash and the created value
			for(k=0; k<8; k++){
				if(pwdhash[k]!=ad_array[i].hash[k]){
					break;
				}
			}

			//If found print to the screen and save into a file
			if(k==8){
				if(ad_array[i].is11g){
					bfhash11g10g((unsigned char*)tmp,&ad_array[i], tmp11g);
				}else{
					memcpy(tmp11g,tmp, pl);
				}
				pthread_mutex_lock(&authinfo_mutex);
				if(!ad_array[i].found){
					printf("Password found: %s:%s:%s:%s\n",ad_array[i].username, tmp11g,
						ad_array[i].sid,ad_array[i].dbname);
					fprintf(p->logfh,"Password found: %s:%s:%s:%s\n",ad_array[i].username, tmp11g,
						ad_array[i].sid,ad_array[i].dbname);
					ad_array[i].found=1;
					(*(p->found))++;
				}
				pthread_mutex_unlock(&authinfo_mutex);
			}

		}

		//Check whether all pwd in password file is found or not. If found, finish the thread
		if(*(p->found)==p->aa_size){
			pthread_mutex_lock(&checked_mutex);
			*(p->checked)+=checked;
			pthread_mutex_unlock(&checked_mutex);
			fclose(dictf);
			return 0;
		}
	}
	pthread_mutex_lock(&checked_mutex);
	*(p->checked)+=checked;
	pthread_mutex_unlock(&checked_mutex);

	fclose(dictf);
	return 0;
}

void* hashthread_pre(void* arg){

	unsigned char key1st[8]={0x01,0x23,0x45,0x67,0x89,0xAB,0xCD,0xEF};
	DES_key_schedule dks;

	char tmp[257];
	//for 11g checking. It will contain the lower uppercase version of the password
	char tmp11g[257];
	FILE* dictf;
	long i=0;
	long long m=0;
	int k=0;
	long checked=0;

	unsigned char key2nd[8];
	unsigned char pwdhash[16];
	unsigned char usernamepwd[1200];
	unsigned char pre_usernamepwd[1000][530];
	unsigned char ctmp[520];
	unsigned char output[1000][300];



	threadparm8i_t *p = (threadparm8i_t*) arg;
	hashinfo11g* ad_array=(hashinfo11g*)p->ad_array;


	DES_set_odd_parity((DES_cblock*)key1st);
	DES_set_key_checked((DES_cblock*)key1st, &dks);

	int pwd_file_size=p->aa_size;

	for(int j = 0;j < pwd_file_size;j++){
		if(ad_array[j].pre_pwdlen > 0){
			memcpy(pre_usernamepwd[j],ad_array[j].pre_pw,ad_array[j].pre_pwdlen);
		}
	}


	dictf = fopen(p->dictfn, "r");
	if (dictf == NULL ){

		return 0;
	}

	//seek forward in the dict file
	for(i=1;i<(p->start+p->checked_by_thread);i++){
		fgets(tmp,255,dictf);
	}

	printf("Start: %lld End: %lld\n", p->start+p->checked_by_thread, p->end);

	for(m=p->start+p->checked_by_thread;m<=p->end;m++){
		fgets(tmp, 255,dictf);
		size_t pl=strlen(tmp);
		tmp[pl-1]='\0';
		memset(ctmp,0, 520);

		for(int q=0;q<pl;q++){tmp[q]=toupper(tmp[q]);}
		str2wide((unsigned char*)tmp, ctmp);
		
		//This will be in the session file
		p->checked_by_thread++;
		for(i = 0;i < p->aa_size;i++){
			if(ad_array[i].found){continue;}
			checked++;
			//This is used when the check_status writes out the current status and speed on to the screen
			p->checked_by_thread_summ=checked;

			if(ad_array[i].cvu_len >= 8){
				int prehash_len=0;
				div_t divresult=div(ad_array[i].pre_pwdlen+2*(pl-1),8);
				if(divresult.rem!=0){
					prehash_len=(divresult.quot+1)*8;
				}else{
					prehash_len=ad_array[i].pre_pwdlen+2*(pl-1);
				}
				memcpy(pre_usernamepwd[i] + ad_array[i].pre_pwdlen,ctmp,(pl-1)*2);
				DES_cbc_encrypt(pre_usernamepwd[i],output[i],(pl-1)*2+ad_array[i].pre_pwdlen, 
						&dks, (DES_cblock*)&ad_array[i].prehash, 1);
				memcpy(key2nd,output[i]+prehash_len-8,8);
				int l = create_usernamepwd(ad_array[i].username, tmp, usernamepwd);
				create_hash(usernamepwd, pwdhash, l, key2nd);
			}else{
				int l = create_usernamepwd(ad_array[i].username, tmp, usernamepwd);
				create_key(usernamepwd, key2nd, l, dks);
				create_hash(usernamepwd, pwdhash, l, key2nd);
			}

			//Compare the hash and the created value
			for(k=0; k<8; k++){
				if(pwdhash[k]!=ad_array[i].hash[k]){
					break;
				}
			}

			//If found print to the screen and save into a file
			if(k==8){
				if(ad_array[i].is11g){
					bfhash11g10g((unsigned char*)tmp,&ad_array[i], tmp11g);
				}else{
					memcpy(tmp11g,tmp, pl);
				}
				pthread_mutex_lock(&authinfo_mutex);
				if(!ad_array[i].found){
					printf("Password found: %s:%s:%s:%s\n",ad_array[i].username, tmp11g,
						ad_array[i].sid,ad_array[i].dbname);
					fprintf(p->logfh,"Password found: %s:%s:%s:%s\n",ad_array[i].username, tmp11g,
						ad_array[i].sid,ad_array[i].dbname);
					ad_array[i].found=1;
					(*(p->found))++;
				}
				pthread_mutex_unlock(&authinfo_mutex);
			}

		}

		//Check whether all pwd in password file is found or not. If found, finish the thread
		if(*(p->found)==p->aa_size){
			pthread_mutex_lock(&checked_mutex);
			*(p->checked)+=checked;
			pthread_mutex_unlock(&checked_mutex);
			fclose(dictf);
			return 0;
		}
	}
	pthread_mutex_lock(&checked_mutex);
	*(p->checked)+=checked;
	pthread_mutex_unlock(&checked_mutex);

	fclose(dictf);
	return 0;
}

//It is used to check the default password list, usernames and the permutation of the usernames.
inline void arraythread_checkpwd(DES_key_schedule dks,  long &checked, void *ad_array,  char pwd[1024], threadparm8i_t *p)
{
	char* username, *sid, *dbname, *src_ip, *src_port, *dst_ip, *dst_port;
	char*  found;
	char is11g;
	long i; int k;
	char tmp11g[1024];

	size_t pl2=strlen(pwd);
	for(i = 0;i < p->aa_size;i++){
		checked++;
		//This is used when the check_status writes out the current status and speed on to the screen
		p->checked_by_thread_summ=checked;
		k=0;
		switch(p->case_which){
			case 'h':
			case 'f':
				if(((hashinfo11g*)ad_array)[i].found!=1){
					k=check_orahash_old(((hashinfo11g*)ad_array)[i].username, pwd, ((hashinfo11g*)ad_array)[i].hash,
						&dks);
				}
				break;
			case '8':
				if(((authinfo8i*)ad_array)[i].found){continue;}
				k=check_auth8i(((authinfo8i*)ad_array)[i].username, pwd, &((authinfo8i*)ad_array)[i],
					&dks);
				break;
			case '9':
				if(((authinfo9i*)ad_array)[i].found){continue;}
				k=check_auth9i(((authinfo9i*)ad_array)[i].username, pwd, &((authinfo9i*)ad_array)[i],
					&dks, p);
				break;
			case 'g':
				if(((authinfo10g*)ad_array)[i].found){continue;}
				k=check_auth10g(((authinfo10g*)ad_array)[i].username, pwd, &((authinfo10g*)ad_array)[i],
					&dks, p);
				break;
		}

		//If found print to the screen and save into a file
		if(k==1){
			is11g='\0';
			sid=dbname=NULL;
			switch(p->case_which){
				case 'h':
				case 'f':
					found=&((hashinfo11g*)ad_array)[i].found;
					is11g=((hashinfo11g*)ad_array)[i].is11g;
					username=((hashinfo11g*)ad_array)[i].username;
					sid=((hashinfo11g*)ad_array)[i].sid;
					dbname=((hashinfo11g*)ad_array)[i].dbname;
					break;
				case '8':
					found=&((authinfo8i*)ad_array)[i].found;
					username=((authinfo8i*)ad_array)[i].username;
					src_ip=((authinfo8i*)ad_array)[i].src_ip;
					dst_ip=((authinfo8i*)ad_array)[i].dst_ip;
					src_port=((authinfo8i*)ad_array)[i].src_port;
					dst_port=((authinfo8i*)ad_array)[i].dst_port;
					break;
				case '9':
					found=&((authinfo9i*)ad_array)[i].found;
					username=((authinfo9i*)ad_array)[i].username;
					src_ip=((authinfo9i*)ad_array)[i].src_ip;
					dst_ip=((authinfo9i*)ad_array)[i].dst_ip;
					src_port=((authinfo9i*)ad_array)[i].src_port;
					dst_port=((authinfo9i*)ad_array)[i].dst_port;
					break;
				case 'g':
					found=&((authinfo10g*)ad_array)[i].found;
					username=((authinfo10g*)ad_array)[i].username;
					src_ip=((authinfo10g*)ad_array)[i].src_ip;
					dst_ip=((authinfo10g*)ad_array)[i].dst_ip;
					src_port=((authinfo10g*)ad_array)[i].src_port;
					dst_port=((authinfo10g*)ad_array)[i].dst_port;
					break;

			}
			if(is11g){
				bfhash11g10g((unsigned char*)pwd,&((hashinfo11g*)ad_array)[i], tmp11g);
			}else{
				memcpy(tmp11g,pwd, pl2+1);
			}
			switch(p->case_which){
				case 'h':
				case 'f':
					pthread_mutex_lock(&authinfo_mutex);
					if(*found==0){
						printf("Password found: %s:%s:%s:%s\n",username, tmp11g,
							sid,dbname);
						fprintf(p->logfh,"Password found: %s:%s:%s:%s\n",username, tmp11g,
							sid,dbname);
						*found=1;
						(*(p->found))++;
					}
					pthread_mutex_unlock(&authinfo_mutex);
					break;
				default:
					pthread_mutex_lock(&authinfo_mutex);
					if(*found==0){
						printf("Password found: %s:%s:%s:%s:%s:%s\n",username, pwd,
							src_ip,src_port,dst_ip,dst_port);
						fprintf(p->logfh,"Password found: %s:%s:%s:%s:%s:%s\n",username, pwd,
							src_ip,src_port,dst_ip,dst_port);
						*found=1;
						(*(p->found))++;
					}
					pthread_mutex_unlock(&authinfo_mutex);
			}
		}

	}
}


//The maximum lenght of usernames is 255 (load_8ipwd_file)
//The std::list needs this for the uniq function
bool compare_str (char* first, char* second){
	return !strncmp(first, second, 255);
}

//hmmm better design is needed
void* arraythread(void* arg){

	unsigned char key1st[8]={0x01,0x23,0x45,0x67,0x89,0xAB,0xCD,0xEF};
	DES_key_schedule dks;

	long i=0;
	long long m=0;
	int k=0;
	long checked=0;

	char** pwarray;
	void* ad_array;

	
	char pwd[1024];
	unsigned long long state;

	threadparm8i_t *p = (threadparm8i_t*) arg;
	pwarray=p->pwarray;
	
	list<char*> usernames(pwarray, pwarray+p->aa_size);
	list<char*>::iterator un_i;
	list<char*> default_pwds(pwarray+p->aa_size, pwarray+p->pwarray_size);
	list<char*>::iterator dp_i;
	
	usernames.unique(compare_str);
	
	switch(p->case_which){
		case 'h':
		case 'f':
			ad_array=(hashinfo11g*)p->ad_array;
		break;
		case '8':
			ad_array=(authinfo8i*)p->ad_array;
		break;
		case '9':
			ad_array=(authinfo9i*)p->ad_array;
		break;
		case 'g':
			ad_array=(authinfo10g*)p->ad_array;
		break;
	}

	

	DES_set_odd_parity((DES_cblock*)key1st);
	DES_set_key_checked((DES_cblock*)key1st, &dks);


	printf("Start array thread with %d number of passwords!\n", p->pwarray_size);

	//Check usernames=pwd
	for(un_i=usernames.begin(); un_i!=usernames.end(); un_i++){
		arraythread_checkpwd(dks, checked, ad_array, *un_i, p);
		if(*(p->found)==p->aa_size){
			pthread_mutex_lock(&checked_mutex);
			*(p->checked)+=checked;
			pthread_mutex_unlock(&checked_mutex);
			//printf("End before finish: %d, %d\n",m, p->aa_size);
			return 0;
		}
	}

	//Check the default passwords from default.txt
	for(dp_i=default_pwds.begin(); dp_i!=default_pwds.end(); dp_i++){
		arraythread_checkpwd(dks, checked, ad_array, *dp_i, p);
		if(*(p->found)==p->aa_size){
			pthread_mutex_lock(&checked_mutex);
			*(p->checked)+=checked;
			pthread_mutex_unlock(&checked_mutex);
			//printf("End before finish: %d, %d\n",m, p->aa_size);
			return 0;
		}
	}

	//Check the permutation of usernames
	if(p->perm > 0){
		for(un_i=usernames.begin(); un_i!=usernames.end(); un_i++){
			int pl=strlen(*un_i);
			state=0;
			while(nextnumbers(*un_i,pwd,pl,state)){
				state++;
				arraythread_checkpwd(dks, checked, ad_array, pwd, p);
			}
			doubleword(*un_i,pwd,pl);
			arraythread_checkpwd(dks, checked, ad_array, pwd, p);
			reverse(*un_i,pwd,pl);
			arraythread_checkpwd(dks, checked, ad_array, pwd, p);
			add123(*un_i,pwd,pl);
			arraythread_checkpwd(dks, checked, ad_array, pwd, p);

			if(p->perm > 1){
				state=0;
				while(nextnumberall(*un_i,pwd,pl,state)){
					state++;
					arraythread_checkpwd(dks, checked, ad_array, pwd, p);
				}
			}

			if(p->perm > 2){
				char ppwd[1024];
				state=0;
				reverse(*un_i,pwd,pl);
				while(nextnumbers(pwd,ppwd,pl,state)){
					state++;
					arraythread_checkpwd(dks, checked, ad_array, ppwd, p);
				}
				state=0;
				while(nextnumberall(pwd,ppwd,pl,state)){
					state++;
					arraythread_checkpwd(dks, checked, ad_array, ppwd, p);
				}
				state=0;
				doubleword(*un_i,pwd,pl);
				while(nextnumbers(pwd,ppwd,pl*2,state)){
					state++;
					arraythread_checkpwd(dks, checked, ad_array, ppwd, p);
				}
				state=0;
				while(nextnumberall(pwd,ppwd,pl*2,state)){
					state++;
					arraythread_checkpwd(dks, checked, ad_array, ppwd, p);
				}
			}

			if(*(p->found)==p->aa_size){
					pthread_mutex_lock(&checked_mutex);
					*(p->checked)+=checked;
					pthread_mutex_unlock(&checked_mutex);
					//printf("End before finish: %d, %d\n",m, p->aa_size);
					return 0;
			}
		}
	}

/*	pthread_mutex_lock(&checked_mutex);
	*(p->checked)+=checked;
	pthread_mutex_unlock(&checked_mutex);*/

	return 0;

}

//This is the template function for bruteforce
void* hashthread_bf(void* arg){

	unsigned char key1st[8]={0x01,0x23,0x45,0x67,0x89,0xAB,0xCD,0xEF};
	DES_key_schedule dks;

	int password_token[12];
	int charset_length;
	long long NumberOfPwds;
	//start bruteforce from
	long long start;
	//stop bruteforce here
	long long stop;
	//max password length
	int length;
	long long counter;

	char all[69]="ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*()-_+=~`[]{}|\\:;\"'<>,.?/";
	char alpha[27]="ABCDEFGHIJKLMNOPQRSTUVWXYZ";
	char alphanum[37]="ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
	char* act_charset=NULL;


	char tmp[257];
	char tmp11g[257];
	long long i=0;
	long long m=0;
	int k=0;
	long long checked=0;

	unsigned char key2nd[8];
	unsigned char pwdhash[16];
	unsigned char usernamepwd[1200];


	threadparm8i_t *p = (threadparm8i_t*) arg;
	hashinfo11g* ad_array=(hashinfo11g*)p->ad_array;
	length=p->length;
	start=p->start+p->checked_by_thread-1;
	stop=p->end;

	printf("Start: %lld End: %lld\n", start, stop);

	DES_set_odd_parity((DES_cblock*)key1st);
	DES_set_key_checked((DES_cblock*)key1st, &dks);



	if(!strncmp(p->charset,"alpha",5)){charset_length = 26;act_charset=alpha;}
	if(!strncmp(p->charset,"alphanum",8)) {charset_length = 36;act_charset=alphanum;}
	if(!strncmp(p->charset,"all",3)) {charset_length = 68;act_charset=all;}
	if(!act_charset){charset_length = 68;act_charset=all;}

	NumberOfPwds=stop-start;

	
	for(int i=0; i<length; i++)
	{
		password_token[i] = -1;
	}

	/*setup the first password, calculate in the number system of charset length
	int j=0;
	tmp_start=start;
	start=start-26;
	for(int i=length-1;i>=0;i--){
		j=length-i-1;
		long double t=pow((long double)charset_length+1,i);
		long long q=start/t;
		if(q!=0){password_token[j]=q-1;}else{password_token[j]=-1;}
		if(q!=0){
			start=start-t*q;
		}	
	}

	int prev=0;
	for ( int j=0; j<length; j++){
		if(password_token[j]!=-1){
			prev=1;
		}
		if(password_token[j]==-1 && prev==1){
			password_token[j]++;
		}
	}*/

	get_firstpwd(start,password_token,charset_length, length);



	counter=0;
	bool endofall = false;
	int pwd_file_size=p->aa_size;

	while((!endofall) && (counter!=NumberOfPwds))
	{
		counter++;
		//This will be in the session file
		p->checked_by_thread++;
		for(int i=length-1;i>=0;i--)
		{
			password_token[i]++;
			if(password_token[i]<charset_length){ 
				break;
			}else if(password_token[0]==charset_length){
				endofall=true;
			}else{
				password_token[i] = 0;
			}
		}


		int k=0;
		for ( int j=0; j<length; j++){
			if(password_token[j]!=-1){
				tmp[k]=act_charset[password_token[j]];
				k++;
			}
		}
		tmp[k]='\0';
		int pl=k;

		///*if(counter>=665){*/printf("pw: %lld %s\n",counter+start,tmp);//}
		for(int i = 0;i < pwd_file_size;i++){
			if(ad_array[i].found){continue;}
			checked++;
			//This is used when the check_status writes out the current status and speed on to the screen
			p->checked_by_thread_summ=checked;
			//produce usernamepwd
			int l = create_usernamepwd(ad_array[i].username, tmp, usernamepwd);

			create_key(usernamepwd, key2nd, l, dks);
			create_hash(usernamepwd, pwdhash, l, key2nd);

			//Compare the hash and the created value
			for(k=0; k<8; k++){
				if(pwdhash[k]!=ad_array[i].hash[k]){
					break;
				}
			}

			//If found print to the screen and save into a file
			if(k==8){
				if(ad_array[i].is11g){
					bfhash11g10g((unsigned char*)tmp,&ad_array[i], tmp11g);
				}else{
					memcpy(tmp11g,tmp, pl+1);
				}
				pthread_mutex_lock(&authinfo_mutex);
				if(!ad_array[i].found){
					printf("Password found: %s:%s:%s:%s\n",ad_array[i].username, tmp11g,
						ad_array[i].sid,ad_array[i].dbname);
					fprintf(p->logfh,"Password found: %s:%s:%s:%s\n",ad_array[i].username, tmp11g,
						ad_array[i].sid,ad_array[i].dbname);
					ad_array[i].found=1;
					(*(p->found))++;
				}
				pthread_mutex_unlock(&authinfo_mutex);
			}

		}

		//Check whether all pwd in password file is found or not. If found, finish the thread
		if(*(p->found)==p->aa_size){
			pthread_mutex_lock(&checked_mutex);
			*(p->checked)+=checked;
			pthread_mutex_unlock(&checked_mutex);
			return 0;
		}
	}
	pthread_mutex_lock(&checked_mutex);
	*(p->checked)+=checked;
	pthread_mutex_unlock(&checked_mutex);
	return 0;
}


//This is the template function for bruteforce
void* hashthread_bf_pre(void* arg){

	unsigned char key1st[8]={0x01,0x23,0x45,0x67,0x89,0xAB,0xCD,0xEF};
	unsigned char ivec[8]={0,0,0,0,0,0,0,0};
	DES_key_schedule dks;

	int password_token[12];
	int charset_length;
	long long NumberOfPwds;
	//start bruteforce from
	long long start;
	//stop bruteforce here
	long long stop;
	//max password length
	int length;
	long long counter;

	char all[69]="ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*()-_+=~`[]{}|\\:;\"'<>,.?/";
	char alpha[27]="ABCDEFGHIJKLMNOPQRSTUVWXYZ";
	char alphanum[37]="ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
	char* act_charset=NULL;


	unsigned char tmp[257];
	char tmp11g[257];
	unsigned char ctmp[520];
	long long i=0;
	long long m=0;
	int k=0;
	long long checked=0;

	unsigned char key2nd[8];
	unsigned char pwdhash[16];
	unsigned char usernamepwd[1200];

	//prehash implementation
	unsigned char pre_usernamepwd[1000][530];
	unsigned char tocheck[8];
	unsigned char post_username[1000];
	//unsigned char output[530];
	unsigned char output[1000][300];


	memset(post_username, 0, sizeof(post_username));
	
	for(int i=0; i < 1000; i++){
		memset(pre_usernamepwd[i],0,sizeof(pre_usernamepwd[i]));
	}

	threadparm8i_t *p = (threadparm8i_t*) arg;
	hashinfo11g* ad_array=(hashinfo11g*)p->ad_array;
	length=p->length;
	start=p->start+p->checked_by_thread-1;
	stop=p->end;

	printf("Start: %lld End: %lld\n", start, stop);

	DES_set_odd_parity((DES_cblock*)key1st);
	DES_set_key_checked((DES_cblock*)key1st, &dks);



	if(!strncmp(p->charset,"alpha",5)){charset_length = 26;act_charset=alpha;}
	if(!strncmp(p->charset,"alphanum",8)) {charset_length = 36;act_charset=alphanum;}
	if(!strncmp(p->charset,"all",3)) {charset_length = 68;act_charset=all;}
	if(!act_charset){charset_length = 68;act_charset=all;}

	NumberOfPwds=stop-start;

	
	for(int i=0; i<length; i++)
	{
		password_token[i] = -1;
	}

	//start=14909;
	get_firstpwd(start,password_token,charset_length, length);

	counter=0;
	bool endofall = false;
	int pwd_file_size=p->aa_size;
	//fo printf when the password length changes
	int prepwdlen=0;

	for(int i = 0;i < pwd_file_size;i++){
		if(ad_array[i].pre_pwdlen > 0){
			memcpy(pre_usernamepwd[i],ad_array[i].pre_pw,ad_array[i].pre_pwdlen);
		}else{
			memcpy(pre_usernamepwd[i],ad_array[i].conv_username, ad_array[i].cvu_len);
		}
	}

	while((!endofall) && (counter!=NumberOfPwds))
	{
		counter++;
		//This will be in the session file
		p->checked_by_thread++;
		for(int i=length-1;i>=0;i--)
		{
			password_token[i]++;
			if(password_token[i]<charset_length){ 
				break;
			}else if(password_token[0]==charset_length){
				endofall=true;
			}else{
				password_token[i] = 0;
			}
		}


		int pwdlen=0;
		for ( int j=0; j<length; j++){
			if(password_token[j]!=-1){
				tmp[pwdlen]=act_charset[password_token[j]];
				pwdlen++;
			}
		}
		tmp[pwdlen]='\0';
		memset(ctmp,0, 520);
		str2wide(tmp, ctmp);

		/*if(counter>=665){printf("pw: %lld %s\n",counter+start,tmp);}
		if(prepwdlen!=pwdlen){
			printf("pwdlen %d\n",pwdlen);
			prepwdlen=pwdlen;
		}*/

		for(int i = 0;i < pwd_file_size;i++){
			if(ad_array[i].found){continue;}
			//if(!strcmp(ad_array[i].username,"DWH")){
		//		printf("%s\n",tmp);
		//	}
			checked++;
			//This is used when the check_status writes out the current status and speed on to the screen
			p->checked_by_thread_summ=checked;
			//produce usernamepwd

			memset(tocheck,0, sizeof(tocheck));
			//memset(pre_usernamepwd,0, sizeof(pre_usernamepwd));
			
			int l = 0;

			int uplen=0;
			div_t divresult;
			//if the username+password length is bigger than 4, the prehahsing is possible
			if((ad_array[i].cvu_len + 2*pwdlen) >= 8){
				//if username length is bigger than 4.
				if(ad_array[i].len >= 4){
					//Number of byte copied from the converted password to the reminder of the username,
					//which is left after the username was prehased during the password file loading.
					int from_pwd_len=0;
					//How many byte is left from the converted password, after the copy.
					int rempwd=(ad_array[i].pre_pwdlen+2*pwdlen)%8;
					//The reminder form the username and the converted password is dividable by 8.
					//Prehashing is still possible if the last octet is not included in the prehash.
					if(rempwd==0 && 2*pwdlen>8){
						from_pwd_len=2*pwdlen-8;
						rempwd=2*pwdlen-from_pwd_len;
					//If the password is long enough (>4), the prehahsing is straightforward.
					}else if(rempwd < 2*pwdlen){
						from_pwd_len=2*pwdlen-rempwd;
					//If the password is short (<4) the whole password will be copied.
					}else if (rempwd >= 2*pwdlen){
						from_pwd_len=2*pwdlen;
						rempwd=0;
					}

					//The length of the result of the DES_cbc
					int prehash_len = from_pwd_len+ad_array[i].pre_pwdlen;
					
					//If the password changed at the given position we have to recalculate the prehash
					if(ctmp[from_pwd_len-1]!=post_username[i]){
						memcpy(pre_usernamepwd[i]+ad_array[i].pre_pwdlen, ctmp, from_pwd_len);
						post_username[i]=ctmp[from_pwd_len-1];
						DES_cbc_encrypt(pre_usernamepwd[i],output[i],from_pwd_len+ad_array[i].pre_pwdlen, 
						&dks, (DES_cblock*)&ad_array[i].prehash, 1);
					}
					
					if(rempwd!=0){
						memcpy(tocheck,ctmp+from_pwd_len,rempwd);
						for(int l=0; l < 8; l++){
							tocheck[l]=tocheck[l]^output[i][prehash_len-8+l];
						}
						DES_ecb_encrypt((DES_cblock*)tocheck,(DES_cblock*)key2nd,&dks,1);
					}else{
						for(int l=0; l < 8; l++){
							if(prehash_len<8){prehash_len=8;}
							key2nd[l]=output[i][prehash_len-8+l];
						}
					}

					uplen=create_usernamepwd(ad_array[i].username, (char*)tmp, usernamepwd);
					create_hash(usernamepwd, pwdhash, uplen, key2nd);
				//If the username is smaller than 4, but the password length is enough for the prehashing
				}else{
					int from_pwd_len=0;
					int rempwd=(ad_array[i].cvu_len+pwdlen*2)%8;
					if(rempwd){
						from_pwd_len=2*pwdlen-rempwd;
					}else{
						from_pwd_len=2*pwdlen;
					}

					if(post_username[i]!=ctmp[from_pwd_len-1]){
						memcpy(pre_usernamepwd[i]+ad_array[i].cvu_len, ctmp, from_pwd_len);
						post_username[i]=ctmp[from_pwd_len-1];
						DES_cbc_encrypt(pre_usernamepwd[i],output[i],ad_array[i].cvu_len + from_pwd_len, 
						&dks, (DES_cblock*)&ivec, 1);
						divresult = div (ad_array[i].cvu_len + from_pwd_len,8);
					}

					if(rempwd!=0){
						memcpy(tocheck,ctmp+from_pwd_len,rempwd);
						for(int l=0; l < 8; l++){
							tocheck[l]=tocheck[l]^output[i][divresult.quot*8-8+l];
						}
						DES_ecb_encrypt((DES_cblock*)tocheck,(DES_cblock*)key2nd,&dks,1);
					}else{
						for(int l=0; l < 8; l++){
							key2nd[l]=output[i][divresult.quot*8-8+l];
						}
					}
					uplen=create_usernamepwd(ad_array[i].username, (char*)tmp, usernamepwd);
					create_hash(usernamepwd, pwdhash, uplen, key2nd);
				}

			}else{ //the username length and password length are not enough for prehashing
				uplen=create_usernamepwd(ad_array[i].username, (char*)tmp, usernamepwd);
				create_key(usernamepwd, key2nd, uplen, dks);
				create_hash(usernamepwd, pwdhash, uplen, key2nd);
			}

	

			//Compare the hash and the created value
			for(k=0; k<8; k++){
				if(pwdhash[k]!=ad_array[i].hash[k]){
					break;
				}
			}

			//If found print to the screen and save into a file
			if(k==8){
				if(ad_array[i].is11g){
					bfhash11g10g((unsigned char*)tmp,&ad_array[i], tmp11g);
				}else{
					memcpy(tmp11g,tmp, pwdlen+1);
				}
				pthread_mutex_lock(&authinfo_mutex);
				if(!ad_array[i].found){
					printf("Password found: %s:%s:%s:%s\n",ad_array[i].username, tmp11g,
						ad_array[i].sid,ad_array[i].dbname);
					fprintf(p->logfh,"Password found: %s:%s:%s:%s\n",ad_array[i].username, tmp11g,
						ad_array[i].sid,ad_array[i].dbname);
					ad_array[i].found=1;
					(*(p->found))++;
				}
				pthread_mutex_unlock(&authinfo_mutex);
			}

		}

		//Check whether all pwd in password file is found or not. If found, finish the thread
		if(*(p->found)==p->aa_size){
			pthread_mutex_lock(&checked_mutex);
			*(p->checked)+=checked;
			pthread_mutex_unlock(&checked_mutex);
			return 0;
		}
	}
	pthread_mutex_lock(&checked_mutex);
	*(p->checked)+=checked;
	pthread_mutex_unlock(&checked_mutex);
	return 0;
}


void* auththread10g(void* arg){
	unsigned char key1st[8]={0x01,0x23,0x45,0x67,0x89,0xAB,0xCD,0xEF};
	DES_key_schedule dks;

	char tmp[257];
	FILE* dictf;
	long i=0;
	long long m=0;
	int k=0;
	long checked=0;

	unsigned char key2nd[8];
	unsigned char pwdhash[16];
	unsigned char pwd[255];
	int pwd_length;
	unsigned char usernamepwd[1200];

	//Extra veriables for 10g
	struct pwd_hash phash={{0x39, 0x09,0x00,0x00},""};
	char authp[300];
	e_key ekey_server;
	e_key ekey_client;
	e_key_comb ekey_comb;
	ekey_server.ver[0]=0x66;
	ekey_server.ver[1]=0x10;
	ekey_server.ver[2]=0x00;
	ekey_server.ver[3]=0x00;

	ekey_client.ver[0]=0x66;
	ekey_client.ver[1]=0x10;
	ekey_client.ver[2]=0x00;
	ekey_client.ver[3]=0x00;

	ekey_comb.ver1[0]=0x11;
	ekey_comb.ver1[1]=0x00;
	ekey_comb.ver1[2]=0x00;
	ekey_comb.ver1[3]=0x00;

	ekey_comb.ver2[0]=0x66;
	ekey_comb.ver2[1]=0x10;
	ekey_comb.ver2[2]=0x00;
	ekey_comb.ver2[3]=0x00;
	//End extra variables

	threadparm8i_t *p = (threadparm8i_t*) arg;
	authinfo10g* ad_array=(authinfo10g*)p->ad_array;


	DES_set_odd_parity((DES_cblock*)key1st);
	DES_set_key_checked((DES_cblock*)key1st, &dks);


	dictf = fopen(p->dictfn, "r");
	if (dictf == NULL ){

		return 0;
	}

	//seek forward in the dict file
	for(i=1;i<(p->start+p->checked_by_thread);i++){
		fgets(tmp,255,dictf);
	}

	printf("Start: %lld End: %lld\n", p->start+p->checked_by_thread, p->end);

	for(m=p->start+p->checked_by_thread;m<=p->end;m++){
		fgets( tmp, 255,dictf);
		size_t pl=strlen(tmp);
		tmp[pl-1]='\0';
		for(int q=0;q<pl;q++){tmp[q]=toupper(tmp[q]);}
		//This will be in the session file 
		p->checked_by_thread++;
		for(i = 0;i < p->aa_size;i++){
			if(ad_array[i].found){continue;}
			//ztvo5pd changes the authp
			memset(authp,0,300);
			memcpy(authp,ad_array[i].authp,ad_array[i].authp_length);
			authp[ad_array[i].authp_length]='\0';
			checked++;
			//This is used when the check_status writes out the current status and speed on to the screen
			p->checked_by_thread_summ=checked;
			//produce usernamepwd
			int l = create_usernamepwd(ad_array[i].username, tmp, usernamepwd);

			//Start 10g authentication algorithm
			create_key(usernamepwd, key2nd, l, dks);
			create_hash(usernamepwd, pwdhash, l, key2nd);

			for(int m = 0; m < 8; m++){
				char* a=chartohex(pwdhash[m]);
				phash.hash[m*2]=a[0];
				phash.hash[m*2+1]=a[1];
			}

			//Decrypt the server session_key
			p->pztvo5kd(&(ekey_server), &(ad_array[i].skey_server), &phash,0);
			//Decrypt the client session_key
			p->pztvo5kd(&(ekey_client), &(ad_array[i].skey_client), &phash,0);

			/*
			The pztvo5csk does the following.
			unsigned char csk[16];
			for(int m=0; m<16; m++){
			csk[m]=ad_array[i].ekey_server.key[m] ^ ad_array[i].ekey_client.key[m];
			}
			MD5(csk, 16, ad_array[i].ekey_comb.key);*/

			p->pztvo5csk(&(ekey_server), &(ekey_client));
			memcpy(ekey_comb.key, ekey_client.key, 0x20);
			pwd_length=ad_array[i].authp_length;
			//Decrypt the AUTH_PASSWORD
			p->pztvo5pd(&(ekey_comb),authp, ad_array[i].authp_length, pwd, &pwd_length);
			pwd[pwd_length]='\0';
			
			//Compare the password and the decrypted value
			if(pwd_length!=0 && pwd_length+1==pl){
				for(k=0; k<pwd_length; k++){
					if(toupper(pwd[k])!=toupper(tmp[k])){
						break;
					}
				}

				//If found print out to the screen and save into a file
				if(k==pwd_length){
					pthread_mutex_lock(&authinfo_mutex);
					if(!ad_array[i].found){
						printf("Password found: %s:%s:%s:%s:%s:%s\n",ad_array[i].username, tmp,
							ad_array[i].src_ip,ad_array[i].src_port,ad_array[i].dst_ip,
							ad_array[i].dst_port);
						fprintf(p->logfh,"Password found: %s:%s:%s:%s:%s:%s\n",ad_array[i].username, tmp,
							ad_array[i].src_ip,ad_array[i].src_port,ad_array[i].dst_ip,
							ad_array[i].dst_port);
						ad_array[i].found=1;
						(*(p->found))++;
					}
					pthread_mutex_unlock(&authinfo_mutex);
				}
			}
			//End 10g authentication algorithm
		}

		//Check whether all pwd in password file is found or not. If found, finish the thread
		if(*(p->found)==p->aa_size){
			pthread_mutex_lock(&checked_mutex);
			*(p->checked)+=checked;
			pthread_mutex_unlock(&checked_mutex);
			fclose(dictf);
			return 0;
		}
	}
	pthread_mutex_lock(&checked_mutex);
	*(p->checked)+=checked;
	pthread_mutex_unlock(&checked_mutex);

	fclose(dictf);
	return 0;
}

void* bfthread10g(void* arg){

	unsigned char key1st[8]={0x01,0x23,0x45,0x67,0x89,0xAB,0xCD,0xEF};
	DES_key_schedule dks;

	int password_token[12];
	int charset_length;
	long long NumberOfPwds;
	//start bruteforce from
	long long start;
	//stop bruteforce here
	long long stop;
	//max password length
	int length;
	long long counter;

	char all[69]="ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*()-_+=~`[]{}|\\:;\"'<>,.?/";
	char alpha[27]="ABCDEFGHIJKLMNOPQRSTUVWXYZ";
	char alphanum[37]="ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
	char* act_charset=NULL;


	char tmp[257];
	long long i=0;
	long long m=0;
	int k=0;
	long long checked=0;

	unsigned char key2nd[8];
	unsigned char pwdhash[16];
	unsigned char usernamepwd[1200];


	//Extra veriables for 10g
	struct pwd_hash phash={{0x39, 0x09,0x00,0x00},""};
	char authp[300];
	int pwd_length;
	//result of the decryption
	unsigned char pwd[255];
	//the size of the to be checked password
	size_t pl;

	e_key ekey_server;
	e_key ekey_client;
	e_key_comb ekey_comb;
	ekey_server.ver[0]=0x66;
	ekey_server.ver[1]=0x10;
	ekey_server.ver[2]=0x00;
	ekey_server.ver[3]=0x00;

	ekey_client.ver[0]=0x66;
	ekey_client.ver[1]=0x10;
	ekey_client.ver[2]=0x00;
	ekey_client.ver[3]=0x00;

	ekey_comb.ver1[0]=0x11;
	ekey_comb.ver1[1]=0x00;
	ekey_comb.ver1[2]=0x00;
	ekey_comb.ver1[3]=0x00;

	ekey_comb.ver2[0]=0x66;
	ekey_comb.ver2[1]=0x10;
	ekey_comb.ver2[2]=0x00;
	ekey_comb.ver2[3]=0x00;
	//End extra variables

	threadparm8i_t *p = (threadparm8i_t*) arg;
	authinfo10g* ad_array=(authinfo10g*)p->ad_array;
	length=p->length;
	start=p->start+p->checked_by_thread-1;
	stop=p->end;

	printf("Start: %lld End: %lld\n", start, stop);

	DES_set_odd_parity((DES_cblock*)key1st);
	DES_set_key_checked((DES_cblock*)key1st, &dks);



	if(!strncmp(p->charset,"alpha",5)){charset_length = 26;act_charset=alpha;}
	if(!strncmp(p->charset,"alphanum",8)) {charset_length = 36;act_charset=alphanum;}
	if(!strncmp(p->charset,"all",3)) {charset_length = 68;act_charset=all;}
	if(!act_charset){charset_length = 68;act_charset=all;}

	NumberOfPwds=stop-start;

	for(int i=0; i<length; i++)
	{
		password_token[i] = -1;
	}

	/*setup the first password, calculate in the number system of charset length
	int j=0;
	for(int i=length-1;i>=0;i--){
		j=length-i-1;
		long double t=pow((long double)charset_length,i);
		long long q=start/t;
		if(q!=0){password_token[j]=q-1;}else{password_token[j]=-1;}
		if(q!=0){
			start=start-t*q;
		}	
	}*/

	get_firstpwd(start,password_token,charset_length, length);

	counter=0;
	bool endofall = false;
	int pwd_file_size=p->aa_size;

	while((!endofall) && (counter!=NumberOfPwds))
	{
		counter++;
		//This will be in the session file
		p->checked_by_thread++;
		for(int i=length-1;i>=0;i--)
		{
			password_token[i]++;
			if(password_token[i]<charset_length){
				break;
			}else if(password_token[0]==charset_length){
				endofall=true;
			}else{
				password_token[i] = 0;
			}
		}

		pl=0;
		memset(tmp,0,12);
		for ( int j=0; j<length; j++){
			if(password_token[j]!=-1){
				tmp[pl]=act_charset[password_token[j]];
				pl++;
			}
		}

		for(int i = 0;i < pwd_file_size;i++){
			if(ad_array[i].found){continue;}
			//ztvo5pd changes the authp
			memcpy(authp,ad_array[i].authp,ad_array[i].authp_length);
			authp[ad_array[i].authp_length]='\0';
			checked++;
			p->checked_by_thread_summ=checked;
			//produce usernamepwd
			int l = create_usernamepwd(ad_array[i].username, tmp, usernamepwd);

			//Start 10g authentication algorithm
			create_key(usernamepwd, key2nd, l, dks);
			create_hash(usernamepwd, pwdhash, l, key2nd);
			for(int m = 0; m < 8; m++){
				char* a=chartohex(pwdhash[m]);
				phash.hash[m*2]=a[0];
				phash.hash[m*2+1]=a[1];
			}

			//Decrypt the server session_key
			p->pztvo5kd(&(ekey_server), &(ad_array[i].skey_server), &phash,0);
			//Decrypt the client session_key
			p->pztvo5kd(&(ekey_client), &(ad_array[i].skey_client), &phash,0);

			/*
			The pztvo5csk does the following.
			unsigned char csk[16];
			for(int m=0; m<16; m++){
			csk[m]=ad_array[i].ekey_server.key[m] ^ ad_array[i].ekey_client.key[m];
			}
			MD5(csk, 16, ad_array[i].ekey_comb.key);*/

			p->pztvo5csk(&(ekey_server), &(ekey_client));
			memcpy(ekey_comb.key, ekey_client.key, 0x20);
			pwd_length=ad_array[i].authp_length;
			//Decrypt the AUTH_PASSWORD
			p->pztvo5pd(&(ekey_comb),authp, ad_array[i].authp_length, pwd, &pwd_length);
			pwd[pwd_length]='\0';


			//Compare the password and the decrypted value
			if(pwd_length!=0 && pwd_length==pl){
				for(k=0; k<pwd_length; k++){
					if(toupper(pwd[k])!=toupper(tmp[k])){
						break;
					}
				}

				//If found print to the screen and save into a file
				if(k==pwd_length){
					pthread_mutex_lock(&authinfo_mutex);
					if(!ad_array[i].found){
						printf("Password found: %s:%s:%s:%s:%s:%s\n",ad_array[i].username, tmp,
							ad_array[i].src_ip,ad_array[i].src_port,ad_array[i].dst_ip,
							ad_array[i].dst_port);
						fprintf(p->logfh,"Password found: %s:%s:%s:%s:%s:%s\n",ad_array[i].username, tmp,
							ad_array[i].src_ip,ad_array[i].src_port,ad_array[i].dst_ip,
							ad_array[i].dst_port);
						ad_array[i].found=1;
						(*(p->found))++;
					}
					pthread_mutex_unlock(&authinfo_mutex);
				}
			}
			//End 10g authentication algorithm

		}

		//Check whether all pwd in password file is found or not. If found, finish the thread
		if(*(p->found)==p->aa_size){
			pthread_mutex_lock(&checked_mutex);
			*(p->checked)+=checked;
			pthread_mutex_unlock(&checked_mutex);
			return 0;
		}
	}
	pthread_mutex_lock(&checked_mutex);
	*(p->checked)+=checked;
	pthread_mutex_unlock(&checked_mutex);

	return 0;
}



void* bfthread9i(void* arg){

	unsigned char key1st[8]={0x01,0x23,0x45,0x67,0x89,0xAB,0xCD,0xEF};
	DES_key_schedule dks;

	int password_token[12];
	int charset_length;
	long long NumberOfPwds;
	//start bruteforce from
	long long start;
	//stop bruteforce here
	long long stop;
	//max password length
	int length;
	long long counter;

	char all[69]="ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*()-_+=~`[]{}|\\:;\"'<>,.?/";
	char alpha[27]="ABCDEFGHIJKLMNOPQRSTUVWXYZ";
	char alphanum[37]="ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
	char* act_charset=NULL;


	char tmp[257];
	long long i=0;
	long long m=0;
	int k=0;
	long long checked=0;

	unsigned char key2nd[8];
	unsigned char pwdhash[16];
	unsigned char usernamepwd[1200];


	//Extra variables for 9i
	struct pwd_hash phash={{0x39, 0x09,0x00,0x00},""};
	char authp[300];
	int pwd_length;
	//the size of the to be checked password
	size_t pl;
	e_key ekey_server;
	ekey_server.ver[0]=0x9A;
	ekey_server.ver[1]=0x03;
	ekey_server.ver[2]=0x00;
	ekey_server.ver[3]=0x00;
	//End extra variables

	threadparm8i_t *p = (threadparm8i_t*) arg;
	authinfo9i* ad_array=(authinfo9i*)p->ad_array;
	length=p->length;
	start=p->start+p->checked_by_thread-1;
	stop=p->end;

	printf("Start: %lld End: %lld\n", start, stop);

	DES_set_odd_parity((DES_cblock*)key1st);
	DES_set_key_checked((DES_cblock*)key1st, &dks);



	if(!strncmp(p->charset,"alpha",5)){charset_length = 26;act_charset=alpha;}
	if(!strncmp(p->charset,"alphanum",8)) {charset_length = 36;act_charset=alphanum;}
	if(!strncmp(p->charset,"all",3)) {charset_length = 68;act_charset=all;}
	if(!act_charset){charset_length = 68;act_charset=all;}

	NumberOfPwds=stop-start;

	for(int i=0; i<length; i++)
	{
		password_token[i] = -1;
	}

	/*setup the first password, calculate in the number system of charset length
	int j=0;
	for(int i=length-1;i>=0;i--){
		j=length-i-1;
		long double t=pow((long double)charset_length,i);
		long long q=start/t;
		if(q!=0){password_token[j]=q-1;}else{password_token[j]=-1;}
		if(q!=0){
			start=start-t*q;
		}	
	}*/

	get_firstpwd(start,password_token,charset_length, length);


	counter=0;
	bool endofall = false;
	int pwd_file_size=p->aa_size;

	while((!endofall) && (counter!=NumberOfPwds))
	{
		counter++;
		//This will be in the session file
		p->checked_by_thread++;
		for(int i=length-1;i>=0;i--)
		{
			password_token[i]++;
			if(password_token[i]<charset_length){
				break;
			}else if(password_token[0]==charset_length){
				endofall=true;
			}else{
				password_token[i] = 0;
			}
		}
		k=0;
		for ( int j=0; j<length; j++){
			if(password_token[j]!=-1){
				tmp[k]=act_charset[password_token[j]];
				k++;
			}
		}
		tmp[k]='\0';
		pl=k;

		//printf("%s:%lld\n",tmp,start);
		for(int i = 0;i < pwd_file_size;i++){
			if(ad_array[i].found){continue;}
			//ztvo5pd changes the authp
			memcpy(authp,ad_array[i].authp,ad_array[i].authp_length);
			authp[ad_array[i].authp_length]='\0';
			checked++;
			//This is used when the check_status writes out the current status and speed on to the screen
			p->checked_by_thread_summ=checked;
			//produce usernamepwd
			int l = create_usernamepwd(ad_array[i].username, tmp, usernamepwd);

			//Start 10g authentication algorithm
			create_key(usernamepwd, key2nd, l, dks);
			create_hash(usernamepwd, pwdhash, l, key2nd);

			for(int m = 0; m < 8; m++){
				char* a=chartohex(pwdhash[m]);
				phash.hash[m*2]=a[0];
				phash.hash[m*2+1]=a[1];
			}

			//Decrypt the server session_key
			p->pztvo5kd(&(ad_array[i].ekey_server), &(ad_array[i].skey_server), &phash,0);
			pwd_length=ad_array[i].authp_length;
			//Decrypt the AUTH_PASSWORD
			p->pztvopd(authp, &pwd_length, &(ad_array[i].ekey_server));
			authp[pwd_length]='\0';

			//If the password is worng, the pwd_length can be 0.
			if(pwd_length!=0 && pwd_length==pl){
				//Compare the password and the decrypted value
				for(k=0; k<pwd_length; k++){
					if(toupper(authp[k])!=toupper(tmp[k])){
						break;
					}
				}

				//If found print to the screen and save into a file
				if(k==pwd_length){
					pthread_mutex_lock(&authinfo_mutex);
					if(!ad_array[i].found){
						printf("Password found: %s:%s:%s:%s:%s:%s\n",ad_array[i].username, tmp,
							ad_array[i].src_ip,ad_array[i].src_port,ad_array[i].dst_ip,
							ad_array[i].dst_port);
						fprintf(p->logfh,"Password found: %s:%s:%s:%s:%s:%s\n",ad_array[i].username, tmp,
							ad_array[i].src_ip,ad_array[i].src_port,ad_array[i].dst_ip,
							ad_array[i].dst_port);
						ad_array[i].found=1;
						(*(p->found))++;
					}
					pthread_mutex_unlock(&authinfo_mutex);
				}
			}
			//End 9i authentication algorithm

		}

		//Check whether all pwd in password file is found or not. If found, exit finish the thread
		if(*(p->found)==p->aa_size){
			pthread_mutex_lock(&checked_mutex);
			*(p->checked)+=checked;
			pthread_mutex_unlock(&checked_mutex);
			return 0;
		}
	}
	pthread_mutex_lock(&checked_mutex);
	*(p->checked)+=checked;
	pthread_mutex_unlock(&checked_mutex);

	return 0;
}



void* auththread9i(void* arg){
	unsigned char key1st[8]={0x01,0x23,0x45,0x67,0x89,0xAB,0xCD,0xEF};
	DES_key_schedule dks;

	char tmp[257];
	FILE* dictf;
	long i=0;
	long long m=0;
	int k=0;
	long long checked=0;

	unsigned char key2nd[8];
	unsigned char pwdhash[16];
	int pwd_length;
	unsigned char usernamepwd[1200];

	//Extra veriables for 9i
	struct pwd_hash phash={{0x39, 0x09,0x00,0x00},""};
	char authp[300];
	e_key ekey_server;
	ekey_server.ver[0]=0x9A;
	ekey_server.ver[1]=0x03;
	ekey_server.ver[2]=0x00;
	ekey_server.ver[3]=0x00;
	//End extra variables

	threadparm8i_t *p = (threadparm8i_t*) arg;
	authinfo9i* ad_array=(authinfo9i*)p->ad_array;


	DES_set_odd_parity((DES_cblock*)key1st);
	DES_set_key_checked((DES_cblock*)key1st, &dks);


	dictf = fopen(p->dictfn, "r");
	if (dictf == NULL ){

		return 0;
	}

	//seek forward in the dict file
	for(i=1;i<(p->start+p->checked_by_thread);i++){
		fgets(tmp,255,dictf);
	}

	printf("Start: %lld End: %lld\n", p->start+p->checked_by_thread, p->end);

	for(m=p->start+p->checked_by_thread;m<=p->end;m++){
		fgets( tmp, 255,dictf);
		size_t pl=strlen(tmp);
		tmp[pl-1]='\0';
		for(int q=0;q<pl;q++){tmp[q]=toupper(tmp[q]);}
		//This will be in the session file 
		p->checked_by_thread++;
		for(i = 0;i < p->aa_size;i++){
			if(ad_array[i].found){continue;}
			//ztvo5pd changes the authp
			memcpy(authp,ad_array[i].authp,ad_array[i].authp_length);
			authp[ad_array[i].authp_length]='\0';
			checked++;
			//This is used when the check_status writes out the current status and speed on to the screen
			p->checked_by_thread_summ=checked;
			//produce usernamepwd
			int l = create_usernamepwd(ad_array[i].username, tmp, usernamepwd);

			//Start 9i authentication algorithm
			create_key(usernamepwd, key2nd, l, dks);
			create_hash(usernamepwd, pwdhash, l, key2nd);

			for(int m = 0; m < 8; m++){
				char* a=chartohex(pwdhash[m]);
				phash.hash[m*2]=a[0];
				phash.hash[m*2+1]=a[1];
			}

			//Decrypt the server session_key
			p->pztvo5kd(&(ekey_server), &(ad_array[i].skey_server), &phash,0);
			pwd_length=ad_array[i].authp_length;
			//Decrypt the AUTH_PASSWORD
			p->pztvopd(authp, &pwd_length, &(ekey_server));
			authp[pwd_length]='\0';

			//Compare the password and the decrypted value
			for(k=0; k<pwd_length; k++){
				if(toupper(authp[k])!=toupper(tmp[k])){
					break;
				}
			}

			//If found print to the screen and save into a file
			if(k==pwd_length){
				pthread_mutex_lock(&authinfo_mutex);
				if(!ad_array[i].found){
					printf("Password found: %s:%s:%s:%s:%s:%s\n",ad_array[i].username, tmp,
						ad_array[i].src_ip,ad_array[i].src_port,ad_array[i].dst_ip,
						ad_array[i].dst_port);
					fprintf(p->logfh,"Password found: %s:%s:%s:%s:%s:%s\n",ad_array[i].username, tmp,
						ad_array[i].src_ip,ad_array[i].src_port,ad_array[i].dst_ip,
						ad_array[i].dst_port);
					ad_array[i].found=1;
					(*(p->found))++;
				}
				pthread_mutex_unlock(&authinfo_mutex);
			}
		}

		//Check whether all pwd in password file is found or not. If found, finish the thread
		if(*(p->found)==p->aa_size){
			pthread_mutex_lock(&checked_mutex);
			*(p->checked)+=checked;
			pthread_mutex_unlock(&checked_mutex);
			fclose(dictf);
			return 0;
		}
	}
	pthread_mutex_lock(&checked_mutex);
	*(p->checked)+=checked;
	pthread_mutex_unlock(&checked_mutex);

	fclose(dictf);
	return 0;
}

inline int bfhash11g10g(unsigned char *pwd, hashinfo11g* hashinfo, char* tmp11g){
	unsigned char md[20];
	int k=1;
	int pwdlen=strlen((char*)pwd);
	unsigned char lpwd[255];
	long long NumberOfPwd=pow((long double)2,pwdlen);
	unsigned char tocheckpwd[255];

	//The pwd is capital already, but we need the all lowercase 
	for(int i=0; i < pwdlen; i++){
		lpwd[i]=tolower(pwd[i]);
	}
	lpwd[pwdlen]='\0';
	

	for(long long i=0; i<NumberOfPwd;i++){
		for(int j=0; j<pwdlen;j++){
			if((i&(k<<j))){
				//printf("%c",lpwd[j]);
				tocheckpwd[j]=lpwd[j];
			}else{
				//printf("%c",pwd[j]);
				tocheckpwd[j]=pwd[j];
			}
		}
		tocheckpwd[pwdlen]='\0';
		create_hash11g(hashinfo->salt,tocheckpwd,md);
		int l;
		for(l=0; l < 20; l++){
			if(hashinfo->hash11g[l]!=md[l]){
				break;
			}
		}
		if(l==20){
			memcpy(tmp11g,tocheckpwd,pwdlen+1);
			return 1;
		}
	}
	
	return 0;
}

__forceinline int create_hash(unsigned char* usernamepwd, unsigned char* hash, unsigned int len, unsigned char* key2nd){

	DES_key_schedule dks;
	DES_cblock ivec={0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00};
	unsigned char output[1300];
	unsigned int outputlen;
	int i;

	//DES_set_odd_parity((DES_cblock*)key2nd);
	DES_set_key_unchecked((DES_cblock*)key2nd, &dks);
	DES_ncbc_encrypt(usernamepwd,output,len,&dks,&ivec,1);

	if(len*8%64){
		outputlen=(len*8+64-len*8%64)/8;
	}else{
		outputlen=len;
	}

	for(i=1; i<9;i++){
		hash[8-i]=output[outputlen-i];
	}
	return 0;
}


__forceinline int create_key(unsigned char* usernamepwd, unsigned char* key2nd, unsigned int len, DES_key_schedule dks){

	DES_cblock ivec={0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00};

	unsigned char output[1300];
	unsigned int outputlen;
	int i;

	if(len*8%64){
		outputlen=(len*8+64-len*8%64)/8;
	}else{
		outputlen=len;
	}

	DES_ncbc_encrypt(usernamepwd,output,len,&dks,&ivec,1);

	for(i=1; i<9;i++){
		key2nd[8-i]=output[outputlen-i];
	}

	
	return 0;
} 

__forceinline int create_key_pre(unsigned char* tocheck, unsigned char* key2nd, unsigned int len, 
								 DES_key_schedule dks, unsigned char* ivec){

	DES_cblock ivec2={0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00};

	unsigned char output[1300];
	unsigned int outputlen;
	int i;

	if(len*8%64){
		outputlen=(len*8+64-len*8%64)/8;
	}else{
		outputlen=len;
	}

	

	DES_cbc_encrypt(tocheck,output,len,&dks,(DES_cblock*)&ivec,1);

	for(i=1; i<9;i++){
		key2nd[8-i]=output[outputlen-i];
	}


	return 0;
} 
inline int decrypt_rnd(unsigned char* capauth_sesskey, unsigned char* auth_sesskey, long len, unsigned char* pwdhash){

	DES_key_schedule dks;
	DES_cblock ivec={0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00};
	unsigned char output[1300];
	int i;

	DES_set_odd_parity((DES_cblock*)pwdhash);
	DES_set_key_unchecked((DES_cblock*)pwdhash, &dks);
	DES_ncbc_encrypt(capauth_sesskey,output,len,&dks,&ivec,0);

	for(i=0; i<8;i++){
		auth_sesskey[i]=output[i];
	}

	return 0;
}

inline int decrypt_pwd(unsigned char* auth_password, unsigned char* pwd, long len, unsigned char* auth_sesskey){
	DES_key_schedule dks;
	DES_cblock ivec={0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00};
	unsigned char output[1300];
	int i;

	DES_set_odd_parity((DES_cblock*)auth_sesskey);
	DES_set_key_unchecked((DES_cblock*)auth_sesskey, &dks);
	DES_ncbc_encrypt(auth_password,output,len,&dks,&ivec,0);
	for(i=0; i<len;i++){
		pwd[i]=output[i];
	}
	return 0;

}

inline  int create_hash11g(unsigned char* salt, unsigned char* pwd, unsigned char *md){
	unsigned char data[300];
	memcpy(data,pwd,strlen((char*)pwd));
	memcpy(data+strlen((char*)pwd),salt,10);
	SHA1(data,strlen((char*)pwd)+10,md);
	return 0;
}

//itoa is not in standard (C/C++), thus it does not exists on Linux.
//This is faster than sprintf...
inline char* chartohex(unsigned char j){

	static char buf[2] = {0};
	int i=1;

	for(;i>=0; --i, j /= 16){
		buf[i] = "0123456789ABCDEF"[j % 16];
	}

	return buf;

}

inline int check_orahash_old(char* username, char* password, unsigned char* hash, DES_key_schedule *dks){
	
	unsigned char usernamepwd[1200];
	unsigned char key2nd[8];
	unsigned char pwdhash[16];
	int k=0;

	//produce usernamepwd
	int l = create_usernamepwd(username, password, usernamepwd);

	create_key(usernamepwd, key2nd, l, *dks);
	create_hash(usernamepwd, pwdhash, l, key2nd);

	//Compare the hash and the created value
	for(k=0; k<8; k++){
		if(pwdhash[k]!=hash[k]){
			break;
		}
	}
	
	if(k==8){
		return 1;
	}else{
		return 0;
	}
}

inline int check_auth8i(char* username, char* password, authinfo8i* authinfo,
					  DES_key_schedule *dks){

	unsigned char key2nd[8];
	unsigned char auth_sesskey[8];
	unsigned char pwdhash[16];
	unsigned char pwd[255];
	unsigned char usernamepwd[1200];
	int k=0;

	int l = create_usernamepwd(username, password, usernamepwd);

	create_key(usernamepwd, key2nd, l, *dks);
	create_hash(usernamepwd, pwdhash, l, key2nd);
	decrypt_rnd(authinfo->capauth_sesskey, auth_sesskey, 8, pwdhash);
	decrypt_pwd(authinfo->auth_password, pwd, authinfo->auth_pwd_len, auth_sesskey);

	//Compare the password and the decrypted value
	for(k=0; k<authinfo->auth_pwd_len; k++){
		if(toupper(pwd[k])!=toupper(password[k])){
			break;
		}
	}

	if(k==authinfo->auth_pwd_len){
		return 1;
	}else{
		return 0;
	}

}

inline int check_auth10g(char* username, char* password, authinfo10g* authinfo,
				 DES_key_schedule *dks, threadparm8i_t *p){

	unsigned char key2nd[8];
	unsigned char pwdhash[16];
	unsigned char pwd[255];
	int pwd_length;
	unsigned char usernamepwd[1200];

	//Extra veriables for 10g
	struct pwd_hash phash={{0x39, 0x09,0x00,0x00},""};
	char authp[300];
	e_key ekey_server;
	e_key ekey_client;
	e_key_comb ekey_comb;
	ekey_server.ver[0]=0x66;
	ekey_server.ver[1]=0x10;
	ekey_server.ver[2]=0x00;
	ekey_server.ver[3]=0x00;

	ekey_client.ver[0]=0x66;
	ekey_client.ver[1]=0x10;
	ekey_client.ver[2]=0x00;
	ekey_client.ver[3]=0x00;

	ekey_comb.ver1[0]=0x11;
	ekey_comb.ver1[1]=0x00;
	ekey_comb.ver1[2]=0x00;
	ekey_comb.ver1[3]=0x00;

	ekey_comb.ver2[0]=0x66;
	ekey_comb.ver2[1]=0x10;
	ekey_comb.ver2[2]=0x00;
	ekey_comb.ver2[3]=0x00;
	//End extra variables

	int pl=strlen(password);
	memcpy(authp,authinfo->authp,authinfo->authp_length);
	authp[authinfo->authp_length]='\0';
	
	//produce usernamepwd
	int l = create_usernamepwd(authinfo->username, password, usernamepwd);

	//Start 10g authentication algorithm
	create_key(usernamepwd, key2nd, l, *dks);
	create_hash(usernamepwd, pwdhash, l, key2nd);

	for(int m = 0; m < 8; m++){
		char* a=chartohex(pwdhash[m]);
		phash.hash[m*2]=a[0];
		phash.hash[m*2+1]=a[1];
	}

	//Decrypt the server session_key
	p->pztvo5kd(&(ekey_server), &(authinfo->skey_server), &phash,0);
	//Decrypt the client session_key
	p->pztvo5kd(&(ekey_client), &(authinfo->skey_client), &phash,0);

	/*
	The pztvo5csk does the following.
	unsigned char csk[16];
	for(int m=0; m<16; m++){
	csk[m]=authinfo->ekey_server.key[m] ^ authinfo->ekey_client.key[m];
	}
	MD5(csk, 16, authinfo->ekey_comb.key);
	*/

	p->pztvo5csk(&(ekey_server), &(ekey_client));
	memcpy(ekey_comb.key, ekey_client.key, 0x20);
	pwd_length=authinfo->authp_length;
	
	//Decrypt the AUTH_PASSWORD
	p->pztvo5pd(&(ekey_comb),authp, authinfo->authp_length, pwd, &pwd_length);
	pwd[pwd_length]='\0';

	//Compare the password and the decrypted value
	int k=0;
	if(pwd_length!=0 && pwd_length==pl){
		for(k=0; k<pwd_length; k++){
			if(toupper(pwd[k])!=toupper(password[k])){
				break;
			}
		}

		if(k==pwd_length){
			return 1;
		}else{
			return 0;
		}
	}
	return 0;
}

inline int check_auth9i(char* username, char* password, authinfo9i* authinfo,
						DES_key_schedule *dks, threadparm8i_t *p){
	
	unsigned char key2nd[8];
	unsigned char pwdhash[16];
	int pwd_length, k;
	unsigned char usernamepwd[1200];

	//Extra veriables for 9i
	struct pwd_hash phash={{0x39, 0x09,0x00,0x00},""};
	char authp[300];
	//End extra variables


	memcpy(authp,authinfo->authp,authinfo->authp_length);
	authp[authinfo->authp_length]='\0';

	int l = create_usernamepwd(authinfo->username, password, usernamepwd);

	//Start 9i authentication algorithm
	create_key(usernamepwd, key2nd, l, *dks);
	create_hash(usernamepwd, pwdhash, l, key2nd);

	for(int m = 0; m < 8; m++){
		char* a=chartohex(pwdhash[m]);
		phash.hash[m*2]=a[0];
		phash.hash[m*2+1]=a[1];
	}

	//Decrypt the server session_key
	p->pztvo5kd(&(authinfo->ekey_server), &(authinfo->skey_server), &phash,0);
	pwd_length=authinfo->authp_length;
	//Decrypt the AUTH_PASSWORD
	p->pztvopd(authp, &pwd_length, &(authinfo->ekey_server));
	authp[pwd_length]='\0';

	//Compare the password and the decrypted value
	for(k=0; k<pwd_length; k++){
		if(toupper(authp[k])!=toupper(password[k])){
			break;
		}
	}

	//If found return 1 otherwise 0
	if(k==pwd_length && k!=0){
		return 1;
	}else{
		return 0;
	}
}


