//The code is released under GPLv2 (http://www.gnu.org/licenses/gpl-2.0.html), by Laszlo Toth.
//Use the code at your own responsibility.
//For help and disclaimer please visit:
//  http://www.soonerorlater.hu/index.khtml?article_id=513

#define _CRT_SECURE_NO_DEPRECATE

#include "stdafx.h"
#include "woraauthbf.h"

int load_8ipwd_file(char* pwdfn, authinfo8i ad_array[]){
	
	char message[1000];
	char t[2];
	unsigned int hexc;

	char tmp[1000];
	FILE* pwdf;
	unsigned int i,j,k;
	
	pwdf = fopen(pwdfn, "r");
	if (pwdf == NULL ){
		
		return -1;
	}
	j=0;
	while(!feof(pwdf)){
		if(-1==fscanf(pwdf, "%999s", tmp)){break;}
		i=0;
		while((tmp[i]!=':') && (i<255)){
			ad_array[j].username[i]=toupper(tmp[i]);
		   	i++;
		}
		if(tmp[i]!=':'){
			sprintf(message, "Wrong password file format! Line: %d\n", j);
			write_error(message);
			return -1;
		}
		
		int l=0;
		for(k=0;k<16;k+=2){
			t[0]=*(tmp+i+1+k);
			t[1]=*(tmp+i+1+k+1);
			hexc = t[0]-48;
			if (hexc > 9) hexc-=7;
			ad_array[j].capauth_sesskey[l]=hexc*16;
			hexc = t[1]-48;
			if (hexc > 9) hexc-=7;
			ad_array[j].capauth_sesskey[l]+=hexc;
			l++;
		}
		i+=18;
		if(tmp[i-1]!=':'){
			sprintf(message, "Wrong password file format! Line: %d\n", j);
			write_error(message);
			return -1;
		}
		k=l=0;
		while((*(tmp+i+k)!=':') && (l<255)){
			t[0]=*(tmp+i+k);
			t[1]=*(tmp+i+k+1);
			hexc = t[0]-48;
			if (hexc > 9) hexc-=7;
			ad_array[j].auth_password[l]=hexc*16;
			hexc = t[1]-48;
			if (hexc > 9) hexc-=7;
			ad_array[j].auth_password[l]+=hexc;
			k+=2;
			l++;
		}
		if(tmp[i-1]!=':'){
			sprintf(message, "Wrong password file format! Line: %d\n", j);
			write_error(message);
			return -1;
		}
		ad_array[j].auth_pwd_len=l;
		
		i+=k;
		k=l=0;
		while((*(tmp+i+1+l)!=':') && (l<15)){
			ad_array[j].src_ip[l]=*(tmp+i+1+l);
			l++;
		}
		if(tmp[i]!=':'){
			sprintf(message, "Wrong password file format! Line: %d\n", j);
			write_error(message);
			return -1;
		}
		ad_array[j].src_ip[15]=0;

		i=i+l+1;
		k=l=0;
		while((*(tmp+i+1+l)!=':') && (l<5)){
			ad_array[j].src_port[l]=*(tmp+i+1+l);
			l++;
		}
		if(tmp[i]!=':'){
			sprintf(message, "Wrong password file format! Line: %d\n", j);
			write_error(message);
			return -1;
		}
		ad_array[j].src_port[5]=0;

		i=i+l+1;
		k=l=0;
		while((*(tmp+i+1+l)!=':') && (l<15)){
			ad_array[j].dst_ip[l]=*(tmp+i+1+l);
			l++;
		}
		if(tmp[i]!=':'){
			sprintf(message, "Wrong password file format! Line: %d\n", j);
			write_error(message);
			return -1;
		}
		ad_array[j].dst_ip[15]=0;

		i=i+l+1;
		k=l=0;
		while((*(tmp+i+1+l)!=':') && (l<5)){
			ad_array[j].dst_port[l]=*(tmp+i+1+l);
			l++;
		}
		if(tmp[i]!=':'){
			sprintf(message, "Wrong password file format! Line: %d\n", j);
			write_error(message);
			return -1;
		}
		ad_array[j].dst_port[5]=0;
		ad_array[j].found=0;
		j++;
	}
	fclose(pwdf);
	return j;

}

int load_10gpwd_file(char* pwdfn, authinfo10g ad_array[]){
	
	char message[1000];
	char tmp[1000];
	FILE* pwdf;
	unsigned int i,j,k;
	
	pwdf = fopen(pwdfn, "r");
	if (pwdf == NULL ){
		
		return -1;
	}
	j=0;
	while(!feof(pwdf)){
		if(-1==fscanf(pwdf, "%999s", tmp)){break;}
		i=0;
		while((tmp[i]!=':') && (i<255)){
			ad_array[j].username[i]=toupper(tmp[i]);
		   	i++;
		}
		if(tmp[i]!=':'){
			sprintf(message, "Wrong password file format! Line: %d\n", j);
			write_error(message);
			return -1;
		}
		
		for(k=0;k<64;k++){
			ad_array[j].skey_server.key[k]=tmp[i+1+k];
		}
		i+=k;
		i++;
		if(tmp[i]!=':'){
			sprintf(message, "Wrong password file format! Line: %d\n", j);
			write_error(message);
			return -1;
		}
		ad_array[j].skey_server.key[64]='\0';
		ad_array[j].skey_server.l=0x40;

		for(k=0;k<64;k++){
			ad_array[j].skey_client.key[k]=tmp[i+1+k];
		}
		i+=k;
		i++;
		if(tmp[i]!=':'){
			sprintf(message, "Wrong password file format! Line: %d\n", j);
			write_error(message);
			return -1;
		}
		ad_array[j].skey_client.key[64]='\0';
		ad_array[j].skey_client.l=0x40;

		i++;
		k=0;
		while((tmp[i+k]!=':') && (k<255)){
			ad_array[j].authp[k] =tmp[i+k];
		   	k++;
		}
		
		i+=k;
		if(tmp[i]!=':'){
			sprintf(message, "Wrong password file format! Line: %d\n", j);
			write_error(message);
			return -1;
		}
		ad_array[j].authp_length=k;
		ad_array[j].authp[k]='\0';

		//Set up the version information in the decrypted session keys structs.
		ad_array[j].ekey_server.ver[0]=0x66;
		ad_array[j].ekey_server.ver[1]=0x10;
		ad_array[j].ekey_server.ver[2]=0x00;
		ad_array[j].ekey_server.ver[3]=0x00;

		ad_array[j].ekey_client.ver[0]=0x66;
		ad_array[j].ekey_client.ver[1]=0x10;
		ad_array[j].ekey_client.ver[2]=0x00;
		ad_array[j].ekey_client.ver[3]=0x00;

		ad_array[j].ekey_comb.ver1[0]=0x11;
		ad_array[j].ekey_comb.ver1[1]=0x00;
		ad_array[j].ekey_comb.ver1[2]=0x00;
		ad_array[j].ekey_comb.ver1[3]=0x00;

		ad_array[j].ekey_comb.ver2[0]=0x66;
		ad_array[j].ekey_comb.ver2[1]=0x10;
		ad_array[j].ekey_comb.ver2[2]=0x00;
		ad_array[j].ekey_comb.ver2[3]=0x00;
				
		i++;
		k=0;
		while((tmp[i+k]!=':') && (k<15)){
			ad_array[j].src_ip[k]=tmp[i+k];
			k++;
		}
		i+=k;
		if(tmp[i]!=':'){
			sprintf(message, "Wrong password file format! Line: %d\n", j);
			write_error(message);
			return -1;
		}
		ad_array[j].src_ip[15]=0;
		
		i++;
		k=0;
		while((tmp[i+k]!=':') && (k<5)){
			ad_array[j].src_port[k]=tmp[i+k];
			k++;
		}
		i+=k;
		if(tmp[i]!=':'){
			sprintf(message, "Wrong password file format! Line: %d\n", j);
			write_error(message);
			return -1;
		}
		ad_array[j].src_port[5]=0;

		i++;
		k=0;
		while((tmp[i+k]!=':') && (k<15)){
			ad_array[j].dst_ip[k]=tmp[i+k];
			k++;
		}
		i+=k;
		if(tmp[i]!=':'){
			sprintf(message, "Wrong password file format! Line: %d\n", j);
			write_error(message);
			return -1;
		}
		ad_array[j].dst_ip[15]=0;

		i++;
		k=0;
		while((tmp[i+k]!=':') && (k<5)){
			ad_array[j].dst_port[k]=tmp[i+k];
			k++;
		}
		i+=k;
		if(tmp[i]!=':'){
			sprintf(message, "Wrong password file format! Line: %d\n", j);
			write_error(message);
			return -1;
		}
		ad_array[j].dst_port[5]=0;

		ad_array[j].found=0;
		j++;
	}
	fclose(pwdf);
	return j;

}

int load_9ipwd_file(char* pwdfn, authinfo9i ad_array[]){
	
	char message[1000];
	char tmp[1000];
	FILE* pwdf;
	unsigned int i,j,k;
	
	pwdf = fopen(pwdfn, "r");
	if (pwdf == NULL ){
		
		return -1;
	}
	j=0;
	while(!feof(pwdf)){
		if(-1==fscanf(pwdf, "%999s", tmp)){break;}
		i=0;
		while((tmp[i]!=':') && (i<255)){
			ad_array[j].username[i]=toupper(tmp[i]);
		   	i++;
		}
		if(tmp[i]!=':'){
			sprintf(message, "Wrong password file format! Line: %d\n", j);
			write_error(message);
			return -1;
		}
		
		for(k=0;k<32;k++){
			ad_array[j].skey_server.key[k]=tmp[i+1+k];
		}
		i+=k;
		i++;
		if(tmp[i]!=':'){
			sprintf(message, "Wrong password file format! Line: %d\n", j);
			write_error(message);
			return -1;
		}
		ad_array[j].skey_server.key[64]='\0';
		ad_array[j].skey_server.l=0x20;

		i++;
		k=0;
		while((tmp[i+k]!=':') && (k<255)){
			ad_array[j].authp[k] =tmp[i+k];
		   	k++;
		}
		
		i+=k;
		if(tmp[i]!=':'){
			sprintf(message, "Wrong password file format! Line: %d\n", j);
			write_error(message);
			return -1;
		}
		ad_array[j].authp_length=k;
		ad_array[j].authp[k]='\0';

		//Set up the version information in the decrypted session keys structs.
		ad_array[j].ekey_server.ver[0]=0x9A;
		ad_array[j].ekey_server.ver[1]=0x03;
		ad_array[j].ekey_server.ver[2]=0x00;
		ad_array[j].ekey_server.ver[3]=0x00;
				
		i++;
		k=0;
		while((tmp[i+k]!=':') && (k<15)){
			ad_array[j].src_ip[k]=tmp[i+k];
			k++;
		}
		i+=k;
		if(tmp[i]!=':'){
			sprintf(message, "Wrong password file format! Line: %d\n", j);
			write_error(message);
			return -1;
		}
		ad_array[j].src_ip[15]=0;
		
		i++;
		k=0;
		while((tmp[i+k]!=':') && (k<5)){
			ad_array[j].src_port[k]=tmp[i+k];
			k++;
		}
		i+=k;
		if(tmp[i]!=':'){
			sprintf(message, "Wrong password file format! Line: %d\n", j);
			write_error(message);
			return -1;
		}
		ad_array[j].src_port[5]=0;

		i++;
		k=0;
		while((tmp[i+k]!=':') && (k<15)){
			ad_array[j].dst_ip[k]=tmp[i+k];
			k++;
		}
		i+=k;
		if(tmp[i]!=':'){
			sprintf(message, "Wrong password file format! Line: %d\n", j);
			write_error(message);
			return -1;
		}
		ad_array[j].dst_ip[15]=0;

		i++;
		k=0;
		while((tmp[i+k]!=':') && (k<5)){
			ad_array[j].dst_port[k]=tmp[i+k];
			k++;
		}
		i+=k;
		if(tmp[i]!=':'){
			sprintf(message, "Wrong password file format! Line: %d\n", j);
			write_error(message);
			return -1;
		}
		ad_array[j].dst_port[5]=0;

		ad_array[j].found=0;
		j++;
	}
	fclose(pwdf);
	return j;

}

long long get_dict_size(char* dictfn ){
	char tmp[1000];
	FILE* dictf;
	long long i=0;
	
	dictf = fopen(dictfn, "r");
	if (dictf == NULL ){
		
		return -1;
	}
	while(!feof(dictf)){
		if(NULL==fgets( tmp, 999,dictf)){break;}
		i++;
	}
	fclose(dictf);
	return i;
}

//select username||':'||password||':'||name||':'||sys_context('USERENV', 'SERVER_HOST')||':' 
//from sys.dba_users, sys.V_$DATABASE;
int load_hashpwd_file(char* pwdfn, hashinfo11g ad_array[]){
	

	char message[1000];
	char t[2];
	unsigned int hexc;

	char tmp[1000];
	FILE* pwdf;
	unsigned int i,j,k,m;
	unsigned char key1st[8]={0x01,0x23,0x45,0x67,0x89,0xAB,0xCD,0xEF};
	DES_cblock ivec={0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00};
	DES_key_schedule dks;
	
	pwdf = fopen(pwdfn, "r");
	if (pwdf == NULL ){
		
		return -1;
	}
	j=0;
	while(!feof(pwdf)){
		if(-1==fscanf(pwdf, "%999s", tmp)){break;}
		i=0;
		while((tmp[i]!=':') && (i<255)){
			ad_array[j].username[i]=toupper(tmp[i]);
		   	i++;
		}
		ad_array[j].username[i]='\0';
		ad_array[j].len=i;

		if(tmp[i]!=':'){
			sprintf(message, "Wrong password file format! Line: %d\n", j);
			write_error(message);
			return -1;
		}
		
		m=0;
		for(int l = 0; ad_array[j].username[l]!= 0; l++){
			ad_array[j].conv_username[m]=0;
			ad_array[j].conv_username[m+1]=ad_array[j].username[l];
			m+=2;
		}
		ad_array[j].cvu_len=m;

		if(ad_array[j].cvu_len >= 8){
			int diff=m%8;		
			for(int l=0; l < diff; l++){
				ad_array[j].pre_pw[l]=ad_array[j].conv_username[m-diff+l];
			}

			ad_array[j].pre_pwdlen=diff;

			unsigned char testecb[600];
			memset(testecb,0,600);
			unsigned char output[1200];
			memset(output,0,600);
			memset(ivec,0,8);
			cpynarrays(ad_array[j].conv_username,testecb,m-diff);

			DES_set_odd_parity((DES_cblock*)key1st);
			DES_set_key_checked((DES_cblock*)key1st, &dks);
			DES_ncbc_encrypt(testecb,output,m-diff,&dks,(DES_cblock*)&ivec,1);
			for(int l=1; l<9;l++){
				ad_array[j].prehash[8-l]=output[m-diff-l];
			}
			
		}

		int l=0;
		for(k=0;k<16;k+=2){
			t[0]=*(tmp+i+1+k);
			t[1]=*(tmp+i+1+k+1);
			hexc = t[0]-48;
			if (hexc > 9) hexc-=7;
			ad_array[j].hash[l]=hexc*16;
			hexc = t[1]-48;
			if (hexc > 9) hexc-=7;
			ad_array[j].hash[l]+=hexc;
			l++;
		}
		i+=18;
		if(tmp[i-1]!=':'){
			sprintf(message, "Wrong password file format! Line: %d\n", j);
			write_error(message);
			return -1;
		}
		k=l=0;
		while((*(tmp+i+k+l)!=':') && (l<255)){
			ad_array[j].sid[l]=toupper(tmp[i+k+l]);
			l++;
		}
		ad_array[j].sid[l]='\0';
		i+=l;
		if(tmp[i]!=':'){
			sprintf(message, "Wrong password file format! Line: %d\n", j);
			write_error(message);
			return -1;
		}

		k=l=0;
		while((*(tmp+i+1+l)!=':') && (l<255)){
			ad_array[j].dbname[l]=*(tmp+i+1+l);
			l++;
		}
		ad_array[j].dbname[l]=0;
		i+=l;
		if(tmp[i+1]!=':'){
			sprintf(message, "Wrong password file format! Line: %d\n", j);
			write_error(message);
			return -1;
		}
		ad_array[j].found=0;
		ad_array[j].is11g=0;
		j++;
	}
	fclose(pwdf);
	return j;
}

//select u.name||':'||u.password||':'||substr(u.spare4,3,63)||':'||d.name||':'||sys_context('USERENV', 'SERVER_HOST')||':' 
//from sys.user$ u, sys.V_$DATABASE d where u.type#=1;
int load_11ghashpwd_file(char* pwdfn, hashinfo11g ad_array[]){
	

	char message[1000];
	char t[2];
	unsigned int hexc;

	char tmp[1000];
	FILE* pwdf;
	unsigned int i,j,k,m;
	unsigned char key1st[8]={0x01,0x23,0x45,0x67,0x89,0xAB,0xCD,0xEF};
	DES_cblock ivec={0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00};
	DES_key_schedule dks;;
	
	pwdf = fopen(pwdfn, "r");
	if (pwdf == NULL ){
		
		return -1;
	}
	j=0;
	while(!feof(pwdf)){
		if(-1==fscanf(pwdf, "%999s", tmp)){break;}
		i=0;
		while((tmp[i]!=':') && (i<255)){
			ad_array[j].username[i]=toupper(tmp[i]);
		   	i++;
		}
		ad_array[j].username[i]='\0';
		ad_array[j].len=i;

		if(tmp[i]!=':'){
			sprintf(message, "Wrong password file format! Line: %d\n", j);
			write_error(message);
			return -1;
		}
		m=0;
		for(int l = 0; ad_array[j].username[l]!= 0; l++){
			ad_array[j].conv_username[m]=0;
			ad_array[j].conv_username[m+1]=ad_array[j].username[l];
			m+=2;
		}
		ad_array[j].cvu_len=m;

		if(ad_array[j].cvu_len >= 8){
			int diff=m%8;		
			for(int l=0; l < diff; l++){
				ad_array[j].pre_pw[l]=ad_array[j].conv_username[m-diff+l];
			}

			ad_array[j].pre_pwdlen=diff;

			unsigned char testecb[600];
			memset(testecb,0,600);
			unsigned char output[1200];
			memset(output,0,600);
			memset(ivec,0,8);
			cpynarrays(ad_array[j].conv_username,testecb,m-diff);

			DES_set_odd_parity((DES_cblock*)key1st);
			DES_set_key_checked((DES_cblock*)key1st, &dks);
			DES_ncbc_encrypt(testecb,output,m-diff,&dks,(DES_cblock*)&ivec,1);
			for(int l=1; l<9;l++){
				ad_array[j].prehash[8-l]=output[m-diff-l];
			}
			
		}

		int l=0;
		for(k=0;k<16;k+=2){
			t[0]=*(tmp+i+1+k);
			t[1]=*(tmp+i+1+k+1);
			hexc = t[0]-48;
			if (hexc > 9) hexc-=7;
			ad_array[j].hash[l]=hexc*16;
			hexc = t[1]-48;
			if (hexc > 9) hexc-=7;
			ad_array[j].hash[l]+=hexc;
			l++;
		}
		i+=18;
		if(tmp[i-1]!=':'){
			sprintf(message, "Wrong password file format! Line: %d\n", j);
			write_error(message);
			return -1;
		}

		l=0;
		for(k=0;k<40;k+=2){
			t[0]=*(tmp+i+k);
			t[1]=*(tmp+i+k+1);
			hexc = t[0]-48;
			if (hexc > 9) hexc-=7;
			ad_array[j].hash11g[l]=hexc*16;
			hexc = t[1]-48;
			if (hexc > 9) hexc-=7;
			ad_array[j].hash11g[l]+=hexc;
			l++;
		}
		l=0;
		for(k=40;k<60;k+=2){
			t[0]=*(tmp+i+k);
			t[1]=*(tmp+i+k+1);
			hexc = t[0]-48;
			if (hexc > 9) hexc-=7;
			ad_array[j].salt[l]=hexc*16;
			hexc = t[1]-48;
			if (hexc > 9) hexc-=7;
			ad_array[j].salt[l]+=hexc;
			l++;
		}
		i+=k;
		k=l=0;
		while((*(tmp+i+1+l)!=':') && (l<255)){
			ad_array[j].sid[l]=toupper(tmp[i+1+l]);
			l++;
		}
		ad_array[j].sid[l]='\0';
		i+=l+1;
		if(tmp[i]!=':'){
			sprintf(message, "Wrong password file format! Line: %d\n", j);
			write_error(message);
			return -1;
		}

		k=l=0;
		while((*(tmp+i+1+l)!=':') && (l<255)){
			ad_array[j].dbname[l]=*(tmp+i+1+l);
			l++;
		}
		ad_array[j].dbname[l]=0;
		i+=l;
		if(tmp[i+1]!=':'){
			sprintf(message, "Wrong password file format! Line: %d\n", j);
			write_error(message);
			return -1;
		}
		ad_array[j].found=0;
		ad_array[j].is11g=1;
		j++;
	}
	fclose(pwdf);
	return j;
}

int load_foundpwdlist(char case_which, void *ad_array, char* pwdfn, int resfn){

	char res_fn1[60];
	char res_fn0[60];
	char res_fn[60];
	char message[1000];
	char* pwdfn_pos;
	FILE* res_fh;
	char index[5];
	int i=0;

	//Prepare the result file name
	//Get the filename without the path

	pwdfn_pos=strrchr(pwdfn,'\\');
	if(pwdfn_pos==NULL){
		strncpy(res_fn1,pwdfn,40);
	}else{
		strncpy(res_fn1,pwdfn_pos+1,40);
	}
	
	res_fn1[40]='\0';
	strncpy(res_fn0,res_fn1,40);
	strcat(res_fn1,".1.res");
	strcat(res_fn0,".0.res");
	
	if(resfn==1){
		res_fh=fopen(res_fn1,"r");
		strncpy(res_fn,res_fn1,60);
	}else{
		res_fh=fopen(res_fn0,"r");
		strncpy(res_fn,res_fn0,60);
	}

	if(res_fh==NULL){
		sprintf(message,"Could not open result file: %s", res_fn);
		write_error(message);
		return -1;
	}

	pcrecpp::RE isnum("[0-9]{1,4}");
	while(!feof(res_fh)){
		if(-1==fscanf(res_fh, "%4s", index)){break;}
		index[4]='\0';
		if(!isnum.FullMatch(index)){
			sprintf(message,"Could not parse %d. line in  res file: %s\n", i, res_fn);
			write_error(message);
		}
		i++;
		switch(case_which){
			case 'h':
			case 'f':
				((hashinfo11g*)ad_array)[atoi(index)].found=1;
				break;
			case '8':
				((authinfo8i*)ad_array)[atoi(index)].found=1;
				break;
			case '9':
				((authinfo9i*)ad_array)[atoi(index)].found=1;
				break;
			case 'g':
				((authinfo10g*)ad_array)[atoi(index)].found=1;
				break;
		}
	}

	return i;
}


int save_foundpwdlist(char case_which, void *ad_array, int aa_size, char* pwdfn, int resfn){

	char res_fn1[60];
	char res_fn0[60];
	char message[1000];
	char* pwdfn_pos;
	FILE* res_fh;

	//Prepare the result file name
	//Get the filename without the path
	pwdfn_pos=strrchr(pwdfn,'\\');
	if(pwdfn_pos==NULL){
		strncpy(res_fn1,pwdfn,40);
	}else{
		strncpy(res_fn1,pwdfn_pos+1,40);
	}
	
	res_fn1[40]='\0';
	strncpy(res_fn0,res_fn1,40);
	strcat(res_fn1,".1.res");
	strcat(res_fn0,".0.res");
	
	if(resfn==1){
		res_fh=fopen(res_fn1,"w");
	}else{
		res_fh=fopen(res_fn0,"w");
	}
	if(res_fh==NULL){
		sprintf(message,"Could not create result file: %s or %s", res_fn0, res_fn1);
		write_error(message);
		return -1;
	}

	//Writing out the index of the found passwords.
	for(int i=0; i < aa_size; i++){
		switch(case_which){
			case 'h':
			case 'f':
				if(((hashinfo11g*)ad_array)[i].found){
					fprintf(res_fh,"%d\n",i);
				}
				break;
			case '8':
				if(((authinfo8i*)ad_array)[i].found){
					fprintf(res_fh,"%d\n",i);
				}
				break;
			case '9':
				if(((authinfo9i*)ad_array)[i].found){
					fprintf(res_fh,"%d\n",i);
				}
				break;
			case 'g':
				if(((authinfo10g*)ad_array)[i].found){
					fprintf(res_fh,"%d\n",i);
				}
				break;
		}

	}
	fclose(res_fh);

	return 1;
}


void* check_status(void* arg){
	threadparm8i_t	*p;
	char message[1000];
	time_t start,end;
	time(&start);
	int tick=0;
	bool which_sess_file=false;
	char sess_fn1[20]="oraauth.sess.1";
	char sess_fn0[20]="oraauth.sess.0";
	FILE* sess_fh;
	//Which result file is the next
	int res_fn;

	p = (threadparm8i_t*) arg;

	char ab[7];
	memset(ab,0,7);

	while(1){
		Sleep(1000);
		pthread_testcancel();
		
		//saving session after ... seconds
		tick++;
		if(tick==60){
			tick=0;
			if(which_sess_file){
				which_sess_file=false;
				sess_fh=fopen(sess_fn1,"w");
				res_fn=1;
				if(sess_fh==NULL){
					sprintf(message,"Could not create session file: %s", sess_fn1);
					write_error(message);
				}
				
			}else{
				which_sess_file=true;
				sess_fh=fopen(sess_fn0,"w");
				res_fn=0;
				if(sess_fh==NULL){
					sprintf(message,"Could not create session file: %s", sess_fn0);
					write_error(message);
				}
			}

			save_foundpwdlist(p->case_which, p->ad_array, p->aa_size, p->pwdfn, res_fn);

			printf("Writing session files...\n");
			for(int i=0;i < p[0].NumberOfProc;i++){
		
				if(p[i].dictfn){
					fprintf(sess_fh,"%s|%s|%s|none|%lld|%lld|0|%lld|%d|\n",p[i].pwdfn,p[i].dictfn,p[i].which,p[i].start,p[i].end,
						p[i].checked_by_thread,*(p[i].found));
				}else{
					fprintf(sess_fh,"%s|none|%s|%s|%lld|%lld|%d|%lld|%d|\n",p[i].pwdfn,p[i].which,p[i].charset,p[i].start,p[i].end,
						p[i].length,p[i].checked_by_thread,*(p[i].found));
				}
			}
				
			fclose(sess_fh);
		}

		long long checked=0;
		
		
		 if(_kbhit()){
			_getch();
			for(int i=0;i < p[0].NumberOfProc;i++){
				checked +=p[i].checked_by_thread_summ;
			}
			time(&end);
			time_t ElapsedTime = end-start;
			printf("Elpased time: %ds",ElapsedTime);
			printf (" Checked passwords: %lld Speed: %lld/s\n", checked, (checked)/ElapsedTime);
			//The distributed mode needs this to get back the result immediatly
			//See getstatus in DistSrv class.  
			fflush(stdout);
		}
	}
}

//Load the session file and initialize the threadparm array with the values
int load_session_file(char* sessfn, threadparm8i_t	**p, char* pwdfn, char* dictfn,
	char* which, char* charset, int *length, int *found){	
	
	char message[1000];
	FILE* sessfh;
	long long checked=0;
	long long start=0;
	long long end=0;
	int NumberOfProc=0;
	threadparm8i_t	*q;
	int lines=0;
	

	char sess_line[1000];
	
	sessfh=fopen(sessfn,"r");
	if (sessfh == NULL ){
		
		return -1;
	}
	while(!feof(sessfh)){
		if(-1==fscanf(sessfh,"%999s",sess_line)){break;}
		NumberOfProc++;
	}
	*p = (threadparm8i_t *) malloc((NumberOfProc+1) * sizeof(**p));
	q=*p;
	fclose(sessfh);

	sessfh=fopen(sessfn,"r");
	while(!feof(sessfh)){
		if(-1==fscanf(sessfh,"%999s",sess_line)){break;}
		int i=0;
		int pos=0;
		while((sess_line[i]!='|') && (i<254)){
			pwdfn[i]=sess_line[i];
			i++;
		}
		pwdfn[i]='\0';
		
		if(i==254){
			sprintf(message, "Wrong session file format! Line: %d\n", lines);
			write_error(message);
			return -1;
		}

		pos=i;
		i=0;
		while((sess_line[i+1+pos]!='|') && (i<254)){
			dictfn[i]=sess_line[i+1+pos];
			i++;
		}
		dictfn[i]='\0';

		if(i==254){
			sprintf(message, "Wrong session file format! Line: %d\n", lines);
			write_error(message);
			return -1;
		}

		pos=pos+i+1;
		i=0;
		while((sess_line[i+1+pos]!='|') && (i<9)){
			which[i]=sess_line[i+1+pos];
			i++;
		}
		which[i]='\0';
		if(i==9){
			sprintf(message, "Wrong session file format! Line: %d\n", lines);
			write_error(message);
			return -1;
		}
		
		pos=pos+i+1;
		i=0;
		while((sess_line[i+1+pos]!='|') && (i<9)){
			charset[i]=sess_line[i+1+pos];
			i++;
		}
		charset[i]='\0';
		if(i==9){
			sprintf(message, "Wrong session file format! Line: %d\n", lines);
			write_error(message);
			return -1;
		}

		char numbers[21];
		//load start;
		pos=pos+i+1;
		i=0;

		while((sess_line[i+1+pos]!='|') && (i<21)){
			numbers[i]=sess_line[i+1+pos];
			i++;
		}
		
		if(i==21){
			sprintf(message, "Wrong session file format! Line: %d\n", lines);
			write_error(message);
			return -1;
		}
		numbers[i]='\0';
		q[lines].start =_atoi64(numbers);

		pos=pos+i+1;
		i=0;
		while((sess_line[i+1+pos]!='|') && (i<21)){
			numbers[i]=sess_line[i+1+pos];
			i++;
		}
		if(i==21){
			sprintf(message, "Wrong session file format! Line: %d\n", lines);
			write_error(message);
			return -1;
		}
		numbers[i]='\0';
		q[lines].end =_atoi64(numbers);
		if(q[lines].end==0){
			sprintf(message, "Wrong session file format! Line: %d\n", lines);
			write_error(message);
			return -1;
		}

		pos=pos+i+1;
		i=0;
		while((sess_line[i+1+pos]!='|') && (i<21)){
			numbers[i]=sess_line[i+1+pos];
			i++;
		}
		if(i==21){
			sprintf(message, "Wrong session file format! Line: %d\n", lines);
			write_error(message);
			return -1;
		}
		numbers[i]='\0';
		*(length) =atoi(numbers);
		if(((*(length)==0) && (dictfn==NULL)) || ((*(length)>10)||(*(length)<0))){
			sprintf(message, "Wrong session file format! Line: %d\n", lines);
			write_error(message);
			return -1;
		}

		pos=pos+i+1;
		i=0;
		while((sess_line[i+1+pos]!='|') && (i<21)){
			numbers[i]=sess_line[i+1+pos];
			i++;
		}
		if(i==21){
			sprintf(message, "Wrong session file format! Line: %d\n", lines);
			write_error(message);
			return -1;
		}
		numbers[i]='\0';
		q[lines].checked_by_thread =_atoi64(numbers);
		/*if(q[lines].checked_by_thread==0){
			sprintf(message, "Wrong session file format! Line: %d\n", lines);
			return -1;
		}*/

		pos=pos+i+1;
		i=0;
		while((sess_line[i+1+pos]!='|') && (i<6)){
			numbers[i]=sess_line[i+1+pos];
			i++;
		}
		if(i==6){
			sprintf(message, "Wrong session file format! Line: %d\n", lines);
			write_error(message);
			return -1;
		}
		numbers[i]='\0';
		*(found) = atoi(numbers);
		if(errno==ERANGE || errno==EINVAL){
			sprintf(message, "Wrong session file format! Line: %d\n", lines);
			write_error(message);
			return -1;
		}
		q[lines].found = found;
		

		lines++;
	}
	
	fclose(sessfh);
	
	
	return NumberOfProc;
}

//Loads the defult.txt to pwdarray. It goes to the topermute array, but this is 
//not permuted, just checked. The defualt.txt is made from the defualt password list 
//from the web site of Pete Finnigan
int load_default_file(char** pwdarray, int PwdFileSize){
	
	FILE* pwdf;
	unsigned int i=0;
	char message[255];
	
	pwdf = fopen("default.txt", "r");
	if (pwdf == NULL ){
		return -1;
	}
	
	while(!feof(pwdf) && i < 1000){
		char *tmp = (char *) malloc(1000);
		memset(tmp,0,1000);
		if(tmp==NULL){
			sprintf(message,"Could not allocate memory!\n");
			write_error(message);
			exit(1);
		}
		if(-1==fscanf(pwdf, "%999s", tmp)){break;}
		pwdarray[i+PwdFileSize]=tmp;
		i++;
	}
	return i;
}

//Opens the file that will stores the found passwords in the working directory
//The log file names depends on the password filename
FILE*  open_log_file(char* pwdfn){

	char message[1000];
	char log_filename[40];
	char* pwdfn_pos;
	FILE* fh;

	//Get the filename without the path
	pwdfn_pos=strrchr(pwdfn,'\\');
	if(pwdfn_pos==NULL){
		strncpy(log_filename,pwdfn,20);
	}else{
		strncpy(log_filename,pwdfn_pos+1,20);
	}
	log_filename[20]='\0';
	strcat(log_filename,".wlog");
	fh=fopen(log_filename,"a");
	if(fh==NULL){
		sprintf(message,"Could not open logfile: %s", log_filename);
		write_error(message);
	}
	setvbuf(fh,NULL,_IONBF,0);
	return fh;

}

int write_error(char *message){
	FILE* errfh;
	errfh=fopen("wora_error.log","a");
	if(errfh==NULL){
		fprintf(stderr,"Could open the error log file!\n");
		return -1;
	}
	fprintf(errfh,"%s", message);
	fclose(errfh);
	printf("%s",message);
	//The distributed mode needs this to get back the result immediatly
	//See startpr in DistSrv class.  
	fflush(stdout);
	return 0;
}

//Seriuos error found in the password generation. These function convert a number
//to the password_token array.
int get_firstpwd(long long ll_start, int* pwd_token, int charset_len, int len)
{
	char str_start[70];
	char all[70]="ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*()-_+=~`[]{}|\\:;\"'<>,.?/";

	BIGNUM *dv,*rem, *rem2, *num, *d, *start, *pos, *subr, *tmp, *exp, *i,*j, *modexp, *divexp;
	BN_CTX* ctx;
	int password_token[1000];

	memset(password_token,-1,1000);
	
	_i64toa(ll_start,str_start,10);
	
	ctx=BN_CTX_new();

	dv=BN_new();
	rem=BN_new();
	num=BN_new();
	d=BN_new();
	start=BN_new();
	pos=BN_new();
	exp=BN_new();
	tmp=BN_new();
	subr=BN_new();
	i=BN_new();
	j=BN_new();
	modexp=BN_new();
	divexp=BN_new();
	rem2=BN_new();

	BN_dec2bn(&start, str_start);

	BN_copy(num,start);
	BN_sub_word(num,1);
	BN_set_word(d,charset_len);
	BN_set_word(pos,4);
	
	BN_CTX_init(ctx);
	BN_set_word(i,0);
	while(BN_cmp(tmp,num)<0){
		BN_add_word(i,1);
		BN_exp(exp,d,i,ctx);
		BN_CTX_init(ctx);
		BN_add(tmp,tmp,exp);
	}

	BN_exp(exp,d,i,ctx);
	BN_sub(tmp,tmp,exp);
	BN_sub(num,num,tmp);

	int l=BN_get_word(i);
	for(int m=0; m < l; m++){
		password_token[m]=0;
	}

	BN_set_word(dv,1);
	BN_set_word(i,0);
	BN_set_word(j,1);

	int k=0;
	while(!BN_is_zero(num))
	{
		BN_CTX_init(ctx);
		BN_exp(divexp,d,i,ctx);
		BN_CTX_init(ctx);
		BN_exp(modexp,d,j,ctx);
		BN_CTX_init(ctx);
		BN_div(dv,rem,num,modexp,ctx);
		BN_CTX_init(ctx);
		BN_div(dv,rem2,rem,divexp,ctx);
		password_token[k]=BN_get_word(dv);
		BN_sub(num,num,rem);
		BN_add_word(i,1);
		BN_add_word(j,1);
		k++;
	}
	
	int n=0;
	for(int m=0;m<l;m++){
		//printf("%d;",password_token[m]);
		n++;
		if((l-m == 1) && password_token[l]==1){
			password_token[l]=0;
			//printf("%d;",password_token[l]);
			n++;
		}
	}
	
	n--;
	int h=0;
	int m=0;
	h=len-l;
	for(; n>=0; n--){
		pwd_token[m+h]=password_token[n];
		m++;
	}

	return 0;

}

//For the testin purposes to set the starting password with --from paramater
int get_number(char* pwd,  int charset_len, BIGNUM* num){

	char all[69]="ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*()-_+=~`[]{}|\\:;\"'<>,.?/";
	
	int len=strlen(pwd);
	BIGNUM* exp;
	BIGNUM* tmp;
	BIGNUM* bn_i;
	BIGNUM* bn_k;
	BIGNUM* bn_cl;
	BN_CTX* ctx;

	ctx=BN_CTX_new();

	exp=BN_new();
	tmp=BN_new();
	bn_i=BN_new();
	bn_k=BN_new();
	bn_cl=BN_new();
	BN_zero(num);
	BN_set_word(bn_cl,charset_len);

	int j=0;
	int k=0;
	for(int i=0; i < len; i++){
		k=len-i-1;
		for(j=0;all[j]!=pwd[k];j++){
		}
		BN_set_word(bn_i,i);
		BN_CTX_init(ctx);
		BN_exp(exp,bn_cl,bn_i,ctx);
		BN_mul_word(exp,j+1);
		BN_add(num,num,exp);
	}

	return 1;
}

//Some helper function for the prehash implementation.
int str2wide(unsigned char* source, unsigned char* target){
	int l = 0;

	for(int k = 0; source[k]!= 0; k++){
		target[l]=0;
		target[l+1]=source[k];
		l+=2;
	}
	return l;
}

int cmpnarrays(unsigned char* array1, unsigned char* array2, int len){

	int i;
	for(i=0; i < len; i++){
		if(array1[i]!=array2[i]){
			break;
		}
	}

	if(i==len){
		return 1;
	}else{
		return 0;
	}
}

void printnarray(unsigned char *array1, int len){
	
	for(int i=0; i < len; i++){
		printf("%c,",array1[i]);
	}
	printf("\n");
}

int cpynarrays(unsigned char* source, unsigned char* target, int len){
	for(int i=0; i < len; i++){
		target[i]=source[i];
	}

	return 0;
}
