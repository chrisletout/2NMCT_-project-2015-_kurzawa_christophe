//The code is released under GPLv2 (http://www.gnu.org/licenses/gpl-2.0.html), by Laszlo Toth.
//Use the code at your own responsibility.
//For help and disclaimer please visit:
//  http://www.soonerorlater.hu/index.khtml?article_id=513

#define _CRT_SECURE_NO_DEPRECATE

#include "stdafx.h"
#include <string.h>
#include <stdlib.h>
#include <math.h>
#include <cctype>
#include "getopt.h"
#include "permute.h"

//+200
int nextnumbers(char *pwd, char* ppwd, int pwd_len, long long  state){
	
	if(state > 219){
		return 0;
	}
	
	int i=state;
	char tmp[3]="";

	strncpy(ppwd,pwd, pwd_len);
	ppwd[pwd_len]='\0';

	if(state<100){
		//pwd1..pwd9
		if(i<10){
			strncat(ppwd,_itoa(i,tmp,10),1);
			ppwd[pwd_len+1]='\0';
		//pwd01..pwd09
		}else if(i<20){
			strncat(ppwd,"0",1);
			strncat(ppwd,_itoa(i-10,tmp,10) ,1);
			ppwd[pwd_len+2]='\0';
		//pwd20..pwd99
		}else{
			strncat(ppwd,_itoa(i,tmp,10) ,2);
			ppwd[pwd_len+2]='\0';
		}
	}else if (i<200){
		i=state-100;
		//1pwd..9pwd
		if(i<10){
			strncpy(ppwd,_itoa(i,tmp,10),1);
			ppwd[1]='\0';
			strncat(ppwd, pwd, pwd_len);
			ppwd[pwd_len+1]='\0';
		//01pwd..09pwd
		}else if(i<20){
			strncpy(ppwd,"0",1);
			strncpy(ppwd+1,_itoa(i-10,tmp,10),1);
			ppwd[2]='\0';
			strncat(ppwd, pwd, pwd_len);
			ppwd[pwd_len+2]='\0';
		//20pwd..99pwd
		}else{
			strncpy(ppwd,_itoa(i,tmp,10),2);
			ppwd[2]='\0';
			strncat(ppwd, pwd, pwd_len);
			ppwd[pwd_len+2]='\0';
		}
	//pwd10..pwd19
	}else if(i < 210){
		strncat(ppwd,_itoa(i-190,tmp,10) ,2);
		ppwd[pwd_len+2]='\0';
	//10pwd..19pwd
	}else{
		strncpy(ppwd,_itoa(i-200,tmp,10),2);
		ppwd[2]='\0';
		strncat(ppwd, pwd, pwd_len);
		ppwd[pwd_len+2]='\0';
	}

	return 1;
}

//+pwd_len*100
int nextnumberall(char* pwd, char* ppwd, int pwd_len, long long state){
	
	//int pwd_len=strlen(pwd);
	char tmp[3]="";

	if(state>(pwd_len-1)*100-1){
		return 0;
	}
	
	int j=state%100;
	int pos=(state-j)/100;
	pos++;

	if(j<10){
		strncpy(ppwd,pwd,pos);
		ppwd[pos]='\0';
		strncat(ppwd,_itoa(j,tmp,10),1);
		ppwd[pos+1]='\0';
		strncat(ppwd,pwd+pos,pwd_len-pos);
	}else{
		strncpy(ppwd,pwd,pos);
		ppwd[pos]='\0';
		strncat(ppwd,_itoa(j,tmp,10),2);
		ppwd[pos+2]='\0';
		strncat(ppwd,pwd+pos,pwd_len-pos);
	}
	return 1;
}

int yearmonthtoend(char* pwd, char* res_array[],long long pos){
	return 0;

}

//+1
int doubleword(char* pwd, char* ppwd, int pwd_len){
	//int pwd_len=strlen(pwd);
	strncpy(ppwd,pwd,pwd_len);
	ppwd[pwd_len]='\0';
	strncat(ppwd,pwd,pwd_len);
	ppwd[pwd_len*2]='\0';
	return 1;
}

//+1
int reverse(char* pwd, char* ppwd, int pwd_len){
	//int pwd_len=strlen(pwd);
	for(int i=pwd_len;i>0;i--){
		ppwd[pwd_len-i]=pwd[i-1];
	}
	ppwd[pwd_len]='\0';
	return 1;
}

//2^pwdlength
int nextlowerupper(char* pwd, char* ppwd, int pwd_len, long long state){
	//int pwd_len=strlen(pwd);
	
	int k=1;
	long long NumberofPwd=pow((long double)2,pwd_len);
	
	if(NumberofPwd <= state){
		return 0;
	}
	
	for(int j=0; j<pwd_len;j++){
		if((state&(k<<j))){
			ppwd[j]=toupper(pwd[j]);
		}else{
			ppwd[j]=tolower(pwd[j]);
		}
	}
	ppwd[pwd_len]='\0';

	return 1;
}

//+1 Add "123" to the end of the password.
int add123(char* pwd, char* ppwd, int pwd_len){
	strncpy(ppwd,pwd,pwd_len);
	strncat(ppwd,"123",3);
	return 1;
}


//Combine all of the permutations. If the "perm" is 0, there are no permutations and returns
//2. If there are permutations and the state is smaller then the possible number of permuted 
//password returns 1, otherwise 0. The function is not optimized.
int permute(char * pwd, char* ppwd, int pwd_len, int perm, unsigned long long state){
	
	char revpwd[512];
	char doublepwd[1024];
	//int pwd_len=strlen(pwd);

	//returns 2 if there is no permutation and the result password will be the
	//input password.
	if(perm==0){
		if(state==0){
			strncpy(ppwd,pwd,pwd_len+1);
			return 2;
		}else{
			return 0;
		}
	}

	memset(revpwd,0,512);
	memset(doublepwd,0,1024);

	int numberall=(pwd_len-1)*100-1;
	int numberall2=(pwd_len*2-1)*100-1;

	if(perm==1){

		if(state==0){
			strncpy(ppwd,pwd,pwd_len+1);
			return 1;
		}

		if(state==1){
			reverse(pwd,ppwd,pwd_len);
			return 1;
		}
		
		if(state==2){
			doubleword(pwd,ppwd,pwd_len);
			return 1;
		}

		if(state < 203){
			nextnumbers(pwd, ppwd, pwd_len, state-2);
			return 1;
		}

		if(state < numberall + 204){
			nextnumberall(pwd, ppwd, pwd_len, state-203);
			return 1;
		}

		if(state < numberall + 204 + 200){
			reverse(pwd,revpwd, pwd_len);
			nextnumbers(revpwd, ppwd, pwd_len, state - (numberall + 204));
			return 1;
		}

		if(state < 2*numberall + 1 + 204 + 200){
			reverse(pwd,revpwd, pwd_len);
			nextnumberall(revpwd, ppwd, pwd_len, state-(numberall + 204 + 200));
			return 1;
		}
		
		if(state < 2*numberall + 204 + 200 + 200){
			doubleword(pwd,doublepwd,pwd_len);
			nextnumbers(doublepwd,ppwd, pwd_len, state - (2*numberall + 204 + 200));
			return 1;
		}

		if(state < 2*numberall + 204 + 200 + 200 + numberall2 + 1){
			doubleword(pwd,doublepwd,pwd_len);
			nextnumberall(doublepwd, ppwd, pwd_len, state-(2*numberall + 204 + 200 + 200));
			return 1;
		}

	}

	return 0;
}