//The code is released under GPLv2 (http://www.gnu.org/licenses/gpl-2.0.html), by Laszlo Toth.
//Use the code at your own responsibility.
//For help and disclaimer please visit:
//  http://www.soonerorlater.hu/index.khtml?article_id=513

#ifndef _ORAAUTH_H
#define _ORAAUTH_H

#define _CRT_SECURE_NO_DEPRECATE
#define PCRE_STATIC


#include <stdio.h>
#include <windows.h>
#include <openssl/des.h>
#include <openssl/MD5.h>
#include <openssl/sha.h>
#include <openssl/bn.h>
#include <time.h>
#include <string.h> 
#include <pthread.h>
#include <time.h>
#include <math.h>
#include <conio.h>
#include <errno.h>
#include <pcrecpp.h>
#include "getopt.h"
#include "permute.h"


typedef struct authinfo8i{
	char username[255];
	unsigned char  capauth_sesskey[8];
	unsigned char  auth_password[255];
	int auth_pwd_len;
	char src_ip[16];
	char dst_ip[16];
	char src_port[6];
	char dst_port[6];
	char found;
}authinfo8i;


/*
Definitation for the authentication brute force 9i and 10g. It is a bit strange,
because I use oracle own dlls.
*/

struct pwd_hash{
    unsigned char ver[4];
    //Oracle password hash
    char hash[40];
};


struct sess_key{
    short int l;
    //AUTH_SESSKEY is sent by the server
    unsigned char key[70];
};

struct e_key{
    unsigned char ver[4];
    //decrypted AUTH_SESSKEY
    unsigned char key[100];
};

struct e_key_comb{
    unsigned char ver1[4];
    unsigned char ver2[4];
    unsigned char key[100];
};
typedef struct authinfo10g{
	char username[255];
	struct sess_key skey_server;
	struct sess_key skey_client;
	struct e_key ekey_server;
	struct e_key ekey_client;
	struct e_key_comb ekey_comb;
	char src_ip[16];
	char dst_ip[16];
	char src_port[6];
	char dst_port[6];
	char found;
	char authp[256];
    long authp_length;
}authinfo10g;


typedef struct authinfo9i{
	char username[255];
	struct sess_key skey_server;
	struct e_key ekey_server;
	char src_ip[16];
	char dst_ip[16];
	char src_port[6];
	char dst_port[6];
	char found;
	char authp[256];
    long authp_length;
}authinfo9i;


typedef struct hashinfo{
	char username[255];
	unsigned char conv_username[600];
	int cvu_len;
	unsigned char  hash[8];
	char sid[255];
	char dbname[255];
	char found;
}hashinfo;


typedef struct hashinfo11g{
	char username[255];
	int len;
	unsigned char conv_username[600];
	int cvu_len;
	unsigned char prehash[8];
	unsigned char pre_pw[255];
	int pre_pwdlen;
	unsigned char  hash[8];
	unsigned char hash11g[20];
	unsigned char salt[10];
	char sid[255];
	char dbname[255];
	char found;
	char is11g;
}hashinfo11g;

//Oracle functions for 9i and 10g authentucation
typedef void (*PZTVO5KD)(e_key*, sess_key*, pwd_hash*, int );
typedef int (*PZTVO5PD)(e_key_comb* , char*, int, unsigned char*, int*);
//ztvo5csk(server,client);
typedef int (*PZTVO5CSK)(e_key*, e_key*);
typedef int (*PZTVOPD)(char*,int*,e_key*);

//Parameters of a thread. It seems this will enough for all types
typedef struct threadparm8i_t{
	long long start;
	long long end;
	//Here is the difference between the types, I cast it inside of a thread
	//to the given values
	void* ad_array;
	//The number of lines (usernames and passords), in the password file
	int aa_size;
	//Dictionary file's name
	char* dictfn;
	//Password file's name
	char* pwdfn;
	//Number of found passwords. If it is equal to the number of users in the pwd file
	//the threads should be quit
	int* found;
	//Number of checked passwors. Every thread should upgrade this
	long long* checked;
	//Number of checked passwords for the check_status
	long long checked_by_thread;
	//Number of checked (passwords X usernames) for the check_status
	long long checked_by_thread_summ;
	//charset for the bruteforce attack
	char* charset;
	//maximum length of the password for the bruteforceattack
	int length;
	//Number of processors for check_status
	int NumberOfProc;
	//The type of the password file
	char* which;
	//In the array thread this is used in the case statement to determine the type
	//of the pwd file. It is faster than the "which" string comparison.
	char case_which;
	PZTVO5KD pztvo5kd;
	PZTVO5PD pztvo5pd;
	PZTVO5CSK pztvo5csk;
	PZTVOPD pztvopd;
	//This will stores the found passwords in the working directory
	FILE* logfh;
	//Array for the array based function. It will be permuted..
	char** pwarray;
	int pwarray_size;
	//Permutation's type
	int perm;
}threadparm8i_t;


//Oracle password hash generator fucntions
__forceinline int create_hash(unsigned char* usernamepwd, unsigned char* hash, unsigned int len, unsigned char* key2nd);
__forceinline int create_key(unsigned char* usernamepwd, unsigned char* key2nd, unsigned int len, DES_key_schedule dks); 
//Prehash implementation
__forceinline int create_key_pre(unsigned char* tocheck, unsigned char* key2nd, unsigned int len, 
								 DES_key_schedule dks, unsigned char* ivec);
__forceinline int create_usernamepwd(char* username, const char* pwd, unsigned char* usernamepwd);
inline int create_usernamepwd2(char* username, const unsigned char* pwd, int pwdlen, unsigned char* usernamepwd);

//Password file loading functions
int load_8ipwd_file(char* pwdfn, authinfo8i ad_array[]);
int load_9ipwd_file(char* pwdfn, authinfo9i ad_array[]);
int load_10gpwd_file(char* pwdfn, authinfo10g ad_array[]);
int load_hashpwd_file(char* pwdfn, hashinfo11g ad_array[]);
int load_11ghashpwd_file(char* pwdfn, hashinfo11g ad_array[]);
long long get_dict_size(char* dictfn);
int load_default_file(char** pwdarray, int PwdFileSize);

void* auththread8i(void* arg);
void* bfthread8i(void* arg);

void* auththread9i(void* arg);
void* bfthread9i(void* arg);


void* auththread10g(void* arg);
void* bfthread10g(void* arg);

void* hashthread(void* arg);
void* hashthread_pre(void* arg);
void* hashthread_bf(void* arg);
void* hashthread_bf_pre(void* arg);

void* bfhashthread11g10g(void* arg);
void* auththread11g10g(void* arg);

void* arraythread(void* arg);
inline int bfhash11g10g(unsigned char *pwd, hashinfo11g* hashinfo, char* tmp11g);



//thread for status handling
void* check_status(void* arg);

int load_session_file(char* sessfn, threadparm8i_t **p, char* pwdfn, char* dictfn,
					  char* which, char* charset, int *length, int *found);

//Opens the file that will stores the found passwords in the working directory
//The log file names depends on the password filename
FILE*  open_log_file(char* pwdfn);


inline int decrypt_rnd(unsigned char* capauth_sesskey, unsigned char* auth_sesskey, long len, unsigned char* pwdhash);
inline int decrypt_pwd(unsigned char* auth_password, unsigned char* pwd, long len, unsigned char* auth_sesskey);
inline  int create_hash11g(unsigned char* salt, unsigned char* pwd, unsigned char *md);

//Functions for the permuted array checks.
inline int check_orahash_old(char* username, char* password, unsigned char* hash, 
							 DES_key_schedule *dks);
inline int check_auth8i(char* username, char* password, authinfo8i* authinfo,
					  DES_key_schedule *dks);
inline int check_auth10g(char* username, char* password, authinfo10g* authinfo,
				 DES_key_schedule *dks, threadparm8i_t *p);

inline int check_auth9i(char* username, char* password, authinfo9i* authinfo,
				 DES_key_schedule *dks, threadparm8i_t *p);

inline char* chartohex(unsigned char j);

int write_error(char *message);

int get_firstpwd(long long ll_start, int* pwd_token, int charset_len, int len);
int get_number(char* pwd,  int charset_len, BIGNUM* num);

//Save the index of the found passwords. The list can be used to leave out the already found passwords
//when the password cracking session is restarted. I generates the result file form the name of the
//password file. The extension will be .res.
int save_foundpwdlist(char case_which, void *ad_array, int aa_size, char* pwdfn, int resfn);
int load_foundpwdlist(char case_which, void *ad_array, char* pwdfn, int resfn);

//Helper functions for prehash attacks
int str2wide(unsigned char* source, unsigned char* target);
int cpynarrays(unsigned char* source, unsigned char* target, int len);
#endif
