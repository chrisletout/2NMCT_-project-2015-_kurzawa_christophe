//The code is released under GPLv2 (http://www.gnu.org/licenses/gpl-2.0.html), by Laszlo Toth.
//Use the code at your own responsibility.
//For help and disclaimer please visit:
//  http://www.soonerorlater.hu/index.khtml?article_id=513

#ifndef _PERMUTE_H
#define _PERMUTE_H


//It returns 0 if the status bigger than possible number of passwords. It returns 1 otherwise.
int nextnumbers(char *pwd, char* ppwd, int pwd_len, long long state);
//It returns 0 if the status bigger than possible number of passwords. It returns 1 otherwise.
int nextnumberall(char* pwd, char* ppwd, int pwd_len, long long state);
//It returns 0 if the status bigger than possible number of passwords. It returns 1 otherwise.
int nextlowerupper(char* pwd, char* ppwd, int pwd_len,long long state);

int doubleword(char* pwd, char* ppwd, int pwd_len);
int reverse(char* pwd, char* ppwd, int pwd_len);
int add123(char* pwd, char* ppwd, int pwd_len);

//Combine all of the permutations. If the "perm" is 0, there are no permutations and returns
//2. If there are permutations and the state is smaller then the possible number of permuted 
//password returns 1, otherwise 0. The function is not optimezed.
int permute(char * pwd, char* ppwd, int pwd_len, int perm, unsigned long long state);

#endif
